#!/bin/bash

# VP Translation Server - Production Startup Script
# Sử dụng Gunicorn để tăng hiệu suất

echo "🚀 Starting VP Translation Server (Production Mode)..."

# Số workers = (2 x CPU cores) + 1
WORKERS=${WORKERS:-4}
THREADS=${THREADS:-2}
PORT=${PORT:-5005}

echo "Configuration:"
echo "  Workers: $WORKERS"
echo "  Threads per worker: $THREADS"
echo "  Port: $PORT"
echo "  Total concurrent requests: $((WORKERS * THREADS))"

# Chạy với gunicorn
gunicorn \
  --bind 0.0.0.0:$PORT \
  --workers $WORKERS \
  --threads $THREADS \
  --worker-class gthread \
  --timeout 60 \
  --keep-alive 5 \
  --access-logfile - \
  --error-logfile - \
  --log-level info \
  server:app

echo "✅ Server started at http://0.0.0.0:$PORT"