import re
import logging
from typing import Dict, List, Tuple, Optional, Any, Callable
from ReplaceChar import SPECIAL_CHARS
import time
import os
import cProfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from model.trie import Trie
import unicodedata

LATIN_CHARS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<>/')

# Vietnamese diacritics for detection
VIETNAMESE_DIACRITICS = set('àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ')

def is_vietnamese_word(text: str) -> bool:
    """
    Check if text contains Vietnamese diacritics (likely Vietnamese word)
    
    Args:
        text (str): Text to check
        
    Returns:
        bool: True if text contains Vietnamese diacritics
    """
    return any(char in VIETNAMESE_DIACRITICS for char in text)

def contains_chinese(text: str) -> bool:
    """
    Check if text contains Chinese characters
    
    Args:
        text (str): Text to check
        
    Returns:
        bool: True if text contains Chinese characters
    """
    # Chinese character ranges
    for char in text:
        code = ord(char)
        # CJK Unified Ideographs and extensions
        if (0x4E00 <= code <= 0x9FFF or  # CJK Unified Ideographs
            0x3400 <= code <= 0x4DBF or  # CJK Extension A
            0x20000 <= code <= 0x2A6DF or  # CJK Extension B
            0x2A700 <= code <= 0x2B73F or  # CJK Extension C
            0x2B740 <= code <= 0x2B81F or  # CJK Extension D
            0x2B820 <= code <= 0x2CEAF or  # CJK Extension E
            0xF900 <= code <= 0xFAFF):     # CJK Compatibility Ideographs
            return True
    return False

def profile_function(func: Callable) -> Callable:
    """
    Decorator to profile a function's performance.
    Disabled to avoid conflicts in concurrent requests.

    Args:
        func (Callable): The function to be profiled.

    Returns:
        Callable: The wrapped function (profiling disabled).
    """
    def wrapper(*args, **kwargs):
        # Profiling disabled to avoid "Another profiling tool is already active" error
        # in concurrent request handling
        return func(*args, **kwargs)
    return wrapper

@profile_function
def load_data() -> Tuple[Trie, Trie, Trie, Dict[str, str], Dict[str, Dict[str, Any]]]:
    """
    Load data from various files into Trie structures and dictionaries.

    Returns:
        Tuple[Trie, Trie, Trie, Dict[str, str], Dict[str, Dict[str, Any]]]: 
        A tuple containing the loaded data structures:
        - names2: Trie containing Names2.txt data
        - names: Trie containing Names.txt data
        - viet_phrase: Trie containing VietPhrase.txt data
        - chinese_phien_am: Dictionary containing ChinesePhienAmWords.txt data
        - loading_info: Dictionary containing information about the loading process
    """
    names2 = Trie()
    names = Trie()
    viet_phrase = Trie()
    chinese_phien_am: Dict[str, str] = {}
    
    loading_info: Dict[str, Dict[str, Any]] = {
        "names2": {"loaded": False, "count": 0, "time": 0},
        "names": {"loaded": False, "count": 0, "time": 0},
        "chinese_words": {"loaded": False, "count": 0, "time": 0},
        "viet_phrase": {"loaded": False, "count": 0, "time": 0}
    }

    data_dir = os.path.join(os.path.dirname(__file__), 'data')

    def load_file(file_name: str, trie: Trie, info_key: str, split_values: bool = False):
        file_path = os.path.join(data_dir, file_name)
        try:
            start_time = time.time()
            with open(file_path, 'r', encoding='utf-8') as f:
                entries = []
                for line in f:
                    parts = line.strip().split('=')
                    if len(parts) == 2:
                        # Normalize BOTH key and value to NFC when loading
                        key = unicodedata.normalize('NFC', parts[0])
                        value = unicodedata.normalize('NFC', parts[1])
                        
                        if split_values:
                            first_value = value.replace("|", "/").split("/")[0]
                            first_value = unicodedata.normalize('NFC', first_value)
                            entries.append((key, first_value))
                        else:
                            entries.append((key, value))
            trie.batch_insert(entries)
            loading_info[info_key]["loaded"] = True
            loading_info[info_key]["count"] = trie.count()
            loading_info[info_key]["time"] = time.time() - start_time
            logging.info(f"Loaded {trie.count()} entries from {file_name} in {loading_info[info_key]['time']:.2f} seconds")
        except FileNotFoundError:
            logging.error(f"{file_name} not found in {data_dir}. Proceeding without {info_key} data.")
        except Exception as e:
            logging.error(f"Error loading {file_name}: {str(e)}")

    # Load Names2.txt
    load_file('Names2.txt', names2, "names2")

    # Load Names.txt with split_values=True
    load_file('Names.txt', names, "names", split_values=True)

    # Load ChinesePhienAmWords.txt
    try:
        start_time = time.time()
        file_path = os.path.join(data_dir, 'ChinesePhienAmWords.txt')
        with open(file_path, 'r', encoding='utf-8') as f:
            chinese_phien_am = {}
            for line in f:
                parts = line.strip().split('=')
                if len(parts) == 2:
                    # Normalize both Chinese character and Vietnamese value
                    key = unicodedata.normalize('NFC', parts[0])
                    value = unicodedata.normalize('NFC', parts[1])
                    chinese_phien_am[key] = value
        loading_info["chinese_words"]["loaded"] = True
        loading_info["chinese_words"]["count"] = len(chinese_phien_am)
        loading_info["chinese_words"]["time"] = time.time() - start_time
        logging.info(f"Loaded {len(chinese_phien_am)} Chinese words in {loading_info['chinese_words']['time']:.2f} seconds")
    except FileNotFoundError:
        logging.error(f"ChinesePhienAmWords.txt not found in {data_dir}.")
    except Exception as e:
        logging.error(f"Error loading ChinesePhienAmWords.txt: {str(e)}")

    # Load VietPhrase.txt with split_values=True
    load_file('VietPhrase.txt', viet_phrase, "viet_phrase", split_values=True)

    return names2, names, viet_phrase, chinese_phien_am, loading_info

# The rest of the file remains unchanged
def read_novel_file(file_path: str) -> Tuple[str, str]:
    """
    Read a novel file with various encoding attempts.

    Args:
        file_path (str): The path to the novel file.

    Returns:
        Tuple[str, str]: A tuple containing the novel text and the successful encoding.

    Raises:
        FileNotFoundError: If the file is not found.
        ValueError: If the file cannot be read with any of the attempted encodings or if the file is empty.
    """
    if not isinstance(file_path, str):
        raise TypeError("file_path must be a string")

    if not file_path.strip():
        raise ValueError("file_path cannot be empty")

    if not os.path.exists(file_path):
        logging.error(f"File not found: {file_path}")
        raise FileNotFoundError(f"File not found: {file_path}")

    if not os.path.isfile(file_path):
        logging.error(f"Path is not a file: {file_path}")
        raise ValueError(f"Path is not a file: {file_path}")

    encodings_to_try = ['utf-8', 'gbk', 'gb2312', 'big5']
    for encoding in encodings_to_try:
        try:
            with open(file_path, 'r', encoding=encoding) as file:
                novel_text = file.read()
            if not novel_text.strip():
                logging.error(f"File is empty: {file_path}")
                raise ValueError(f"File is empty: {file_path}")
            logging.info(f"Successfully read the novel file using {encoding} encoding.")
            return novel_text, encoding
        except UnicodeDecodeError:
            logging.warning(f"Failed to read with {encoding} encoding.")
        except Exception as e:
            logging.error(f"Error reading file with {encoding} encoding: {str(e)}")
    
    logging.error(f"Unable to read the novel file with any of the attempted encodings: {encodings_to_try}")
    raise ValueError(f"Unable to read the novel file with any of the attempted encodings: {encodings_to_try}")

def replace_special_chars(text: str) -> str:
    """
    Replace special characters in the text with their Vietnamese equivalents.

    Args:
        text (str): The input text containing special characters.

    Returns:
        str: The text with special characters replaced.
    """
    for han, viet in SPECIAL_CHARS.items():
        text = text.replace(han, viet)
    return text

@profile_function
def convert_to_sino_vietnamese(text: str, names2: Trie, names: Trie, viet_phrase: Trie, chinese_phien_am: Dict[str, str]) -> str:
    """
    Convert Chinese text to Sino-Vietnamese.

    Args:
        text (str): The input Chinese text.
        names2 (Trie): Trie containing Names2.txt data.
        names (Trie): Trie containing Names.txt data.
        viet_phrase (Trie): Trie containing VietPhrase.txt data.
        chinese_phien_am (Dict[str, str]): Dictionary containing ChinesePhienAmWords.txt data.

    Returns:
        str: The converted Sino-Vietnamese text.
    """
    text = replace_special_chars(text)
    
    tokens = []
    i = 0
    text_len = len(text)
    
    # Process entire text at once without chunking to avoid splitting words
    while i < text_len:
        # Check for Vietnamese words first (skip translation)
        # Look ahead to find word boundaries and check if it's Vietnamese
        viet_start = i
        while i < text_len and (text[i].isalpha() or text[i] in VIETNAMESE_DIACRITICS):
            i += 1
        if i > viet_start:
            word = text[viet_start:i]
            # If word contains Vietnamese diacritics and no Chinese, keep it as-is
            if is_vietnamese_word(word) and not contains_chinese(word):
                tokens.append(word)
                continue
            else:
                # Reset position to process as Chinese
                i = viet_start
        
        # Check for a sequence of Latin characters (English, numbers, etc.)
        latin_start = i
        while i < text_len and text[i] in LATIN_CHARS:
            i += 1
        if i > latin_start:
            latin_text = text[latin_start:i]
            tokens.append(latin_text)
            continue
        
        # Check Names2 first (highest priority)
        name2_match, value = names2.find_longest_prefix(text[i:])
        if name2_match:
            tokens.append(value)
            i += len(name2_match)
            continue
        
        # Then check Names
        name_match, value = names.find_longest_prefix(text[i:])
        if name_match:
            tokens.append(value)
            i += len(name_match)
            continue
        
        # Try to find the longest prefix in VietPhrase
        max_prefix, value = viet_phrase.find_longest_prefix(text[i:])
        if max_prefix:
            if value != "":
                tokens.append(value)
            i += len(max_prefix)
        else:
            # If no match found, fallback to ChinesePhienAmWord
            char = text[i]
            fallback_value = chinese_phien_am.get(char, char)
            tokens.append(fallback_value)
            i += 1
    
    result = rephrase(tokens)
    
    # Normalize Unicode to NFC (composed form) to fix separated Vietnamese characters
    # This fixes issues like "L â m" becoming "Lâm"
    result = unicodedata.normalize('NFC', result)
    
    return result

def rephrase(tokens: List[str]) -> str:
    """
    Rephrase the tokens to form a properly formatted sentence with automatic capitalization.

    Args:
        tokens (List[str]): A list of tokens to be rephrased.

    Returns:
        str: The rephrased text.
    """
    non_word = set('"[{ ,!?;\'.')
    result = []
    last_token_empty = False
    should_capitalize_next = True  # Flag to track if next word should be capitalized

    # Normalize each token BEFORE processing to fix decomposed Vietnamese characters
    normalized_tokens = [unicodedata.normalize('NFC', token) for token in tokens]

    for i, token in enumerate(normalized_tokens):
        if token.strip():  # Non-empty token
            if i == 0 or token not in non_word:
                if result and not last_token_empty:
                    result.append(' ')
                # Capitalize first letter if needed
                if should_capitalize_next and token and token[0].isalpha():
                    token = token[0].upper() + token[1:]
                    should_capitalize_next = False
            elif token not in non_word and not last_token_empty:
                result.append(' ')
            result.append(token)
            last_token_empty = False
        else:  # Empty token
            if not last_token_empty and i > 0:
                result.append(' ')
            result.append(token)
            last_token_empty = True

    text = ''.join(result).strip()
    
    # Normalize again after joining
    text = unicodedata.normalize('NFC', text)
    
    # Remove spaces after left quotation marks and capitalize next letter
    text = re.sub(r'([\[\"\'])\s*(\w)', lambda m: m.group(1) + m.group(2).upper(), text)
    # Remove spaces before right quotation marks
    text = re.sub(r'\s+(["\'\]])', r'\1', text)
    # Add space after ? and ! marks and capitalize next letter
    text = re.sub(r'([?!⟨:«])\s+(\w)', lambda m: m.group(1) + ' ' + m.group(2).upper(), text)
    # Remove spaces before colon and semicolon
    text = re.sub(r'\s+([;:?!.])', r'\1', text)
    # Add space after a single dot, but not after triple dots, and capitalize next letter
    text = re.sub(r'(?<!\.)\.(?!\.)\s+(\w)', lambda m: '. ' + m.group(1).upper(), text)
    text = re.sub(r'(\n)\s*(\w)', lambda m: m.group(1) + m.group(2).upper(), text)
    
    # Final normalization to ensure all Vietnamese characters are composed
    text = unicodedata.normalize('NFC', text)
    
    # Fix Vietnamese character spacing issue: "L â m" → "Lâm", "Th ất" → "Thất"
    # This happens when Vietnamese characters are tokenized separately
    # We need to merge single characters that are separated by single spaces
    
    # Strategy: Find sequences of single characters (letters/Vietnamese) separated by spaces
    # and merge them if they form a word (length <= 15 characters to avoid merging sentences)
    
    # Pattern explanation:
    # \b - word boundary
    # [A-ZÀ-ỸĐa-zà-ỹđ] - any letter (uppercase, lowercase, Vietnamese)
    # (?:\s+[A-ZÀ-ỸĐa-zà-ỹđ])+ - one or more groups of (space + single letter)
    # \b - word boundary
    # This will match: "L â m", "Th ất", "Hù ng", "Tr ư ờ ng", etc.
    
    def merge_spaced_letters(match):
        """Merge spaced letters if result is reasonable word length"""
        merged = match.group(0).replace(' ', '')
        # Only merge if result is a reasonable word (2-15 chars)
        # This prevents merging entire sentences
        if 2 <= len(merged) <= 15:
            return merged
        return match.group(0)
    
    # Apply the pattern to merge spaced letters
    text = re.sub(
        r'\b[A-ZÀ-ỸĐa-zà-ỹđ](?:\s+[A-ZÀ-ỸĐa-zà-ỹđ])+\b',
        merge_spaced_letters,
        text
    )

    return text

@profile_function
def process_paragraph(paragraph: str, names2: Trie, names: Trie, viet_phrase: Trie, chinese_phien_am: Dict[str, str]) -> str:
    """
    Process a single paragraph by converting it to Sino-Vietnamese.

    Args:
        paragraph (str): The input paragraph in Chinese.
        names2 (Trie): Trie containing Names2.txt data.
        names (Trie): Trie containing Names.txt data.
        viet_phrase (Trie): Trie containing VietPhrase.txt data.
        chinese_phien_am (Dict[str, str]): Dictionary containing ChinesePhienAmWords.txt data.

    Returns:
        str: The processed paragraph in Sino-Vietnamese.
    """
    converted = convert_to_sino_vietnamese(paragraph, names2, names, viet_phrase, chinese_phien_am)
    return converted

def convert_filename(filename: str, names2: Trie, names: Trie, viet_phrase: Trie, chinese_phien_am: Dict[str, str]) -> str:
    """
    Convert a Chinese filename to Sino-Vietnamese.

    Args:
        filename (str): The input filename in Chinese.
        names2 (Trie): Trie containing Names2.txt data.
        names (Trie): Trie containing Names.txt data.
        viet_phrase (Trie): Trie containing VietPhrase.txt data.
        chinese_phien_am (Dict[str, str]): Dictionary containing ChinesePhienAmWords.txt data.

    Returns:
        str: The converted filename in Sino-Vietnamese.
    """
    base_name = os.path.basename(filename)
    name_without_ext, ext = os.path.splitext(base_name)
    converted_name = convert_to_sino_vietnamese(name_without_ext, names2, names, viet_phrase, chinese_phien_am)
    
    # Remove any characters that are not allowed in filenames
    converted_name = ''.join(char for char in converted_name if char not in r'<>:"/\|?*')
    
    return f"{converted_name}{ext}"

@profile_function
def process_novel(novel_text: str, names2: Trie, names: Trie, viet_phrase: Trie, chinese_phien_am: Dict[str, str], 
                  progress_callback: Optional[Callable[[float], bool]] = None,
                  detect_chapters_enabled: bool = False,
                  start_chapter: Optional[int] = None,
                  end_chapter: Optional[int] = None,
                  update_cache_percentage_callback: Optional[Callable[[], None]] = None) -> str:
    """
    Process an entire novel by converting it to Sino-Vietnamese.

    Args:
        novel_text (str): The input novel text in Chinese.
        names2 (Trie): Trie containing Names2.txt data.
        names (Trie): Trie containing Names.txt data.
        viet_phrase (Trie): Trie containing VietPhrase.txt data.
        chinese_phien_am (Dict[str, str]): Dictionary containing ChinesePhienAmWords.txt data.
        progress_callback (Optional[Callable[[float], bool]]): A callback function to report progress.
        detect_chapters_enabled (bool): Whether to detect and process chapters (not used in this version).
        start_chapter (Optional[int]): The starting chapter number for conversion (not used in this version).
        end_chapter (Optional[int]): The ending chapter number for conversion (not used in this version).
        update_cache_percentage_callback (Optional[Callable[[], None]]): A callback function to update the cache percentage.

    Returns:
        str: The processed novel in Sino-Vietnamese.
    """
    paragraphs = novel_text.split('\n')
    converted_paragraphs = []
    total_paragraphs = len(paragraphs)

    for i, paragraph in enumerate(paragraphs):
        converted = convert_to_sino_vietnamese(paragraph, names2, names, viet_phrase, chinese_phien_am)
        converted_paragraphs.append(converted)
        
        if progress_callback:
            progress = (i + 1) / total_paragraphs
            if progress_callback(progress):
                break  # Stop processing if the callback returns True
        
        if update_cache_percentage_callback:
            update_cache_percentage_callback()

    converted_text = '\n'.join(converted_paragraphs)
    return converted_text


def process_chunk(chunk: str, names2: Trie, names: Trie, viet_phrase: Trie, chinese_phien_am: Dict[str, str],
                  progress_callback: Optional[Callable[[float], bool]] = None,
                  update_cache_percentage_callback: Optional[Callable[[], None]] = None) -> str:
    """
    Process a chunk of text by converting it to Sino-Vietnamese.

    Args:
        chunk (str): The input chunk of text in Chinese.
        names2 (Trie): Trie containing Names2.txt data.
        names (Trie): Trie containing Names.txt data.
        viet_phrase (Trie): Trie containing VietPhrase.txt data.
        chinese_phien_am (Dict[str, str]): Dictionary containing ChinesePhienAmWords.txt data.
        progress_callback (Optional[Callable[[float], bool]]): A callback function to report progress.
        update_cache_percentage_callback (Optional[Callable[[], None]]): A callback function to update the cache percentage.

    Returns:
        str: The processed chunk in Sino-Vietnamese.
    """
    return process_novel(chunk, names2, names, viet_phrase, chinese_phien_am, progress_callback, False, None, None, update_cache_percentage_callback)


