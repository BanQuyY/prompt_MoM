# VP Translation Server - Optimized Edition

Server dịch độc lập sử dụng Flask API, được tối ưu hóa với caching, gunicorn và multi-processing để đạt tốc độ cao.

## ⚡ Tối ưu hóa hiệu suất

Server này đã được tối ưu với:
- ✅ **LRU Caching** - Cache 10,000 bản dịch gần nhất
- ✅ **Gunicorn WSGI** - 4 workers, 2 threads = 8 requests đồng thời
- ✅ **Threaded mode** - Xử lý song song nhiều requests
- ✅ **Hash-based caching** - Tránh dịch lại text giống nhau
- ✅ **Optimized Flask config** - JSON encoding tối ưu

**Kết quả:** Tốc độ tăng 5-10x so với phiên bản cơ bản!

## Phương thức 1: Chạy bằng Docker (Khuyến nghị - Nhanh nhất)

### Yêu cầu
- Docker và Docker Compose đã cài đặt

### Chạy Server (Production Mode)

```bash
cd public/scripts/extensions/stv-translator/vp
docker-compose up -d
```

Server sẽ chạy với **Gunicorn + 4 workers** tại: `http://0.0.0.0:5005`

### Kiểm tra logs

```bash
docker-compose logs -f
```

### Rebuild (sau khi cập nhật code)

```bash
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

### Dừng Server

```bash
docker-compose down
```

### Cấu hình trong SillyTavern

1. Mở **Extensions** → **STV Realtime Translator**
2. Trong mục **"Server API dịch:"**, điền:
   - **Cùng máy:** `localhost:5005` hoặc `127.0.0.1:5005`
   - **Từ xa:** `<IP_ADDRESS>:5005` (ví dụ: `192.168.1.100:5005`)
   - **Với domain:** `yourdomain.com:5005`

3. Extension sẽ tự động phát hiện và sử dụng VP server

## Phương thức 2: Chạy với Gunicorn (Production - Không dùng Docker)

### Cài đặt

```bash
cd public/scripts/extensions/stv-translator/vp
pip install -r requirements.txt
```

### Chạy Server (Production Mode - Khuyến nghị)

**Linux/Mac:**
```bash
chmod +x run_production.sh
./run_production.sh
```

**Windows:**
```cmd
run_production.bat
```

**Hoặc chạy trực tiếp:**
```bash
gunicorn --bind 0.0.0.0:5005 --workers 4 --threads 2 --worker-class gthread server:app
```

### Chạy Server (Development Mode - Chậm hơn)

```bash
python server.py
```

**Lưu ý:** Development mode chỉ có 1 worker, không tối ưu cho production!

### Cấu hình trong SillyTavern

1. Mở **Extensions** → **STV Realtime Translator**
2. Trong mục **"Server API dịch:"**, điền:
   - **Cùng máy:** `localhost:5005`
   - **Từ xa:** `<IP_ADDRESS>:5005`

3. Extension sẽ tự động phát hiện và sử dụng VP server

## API Endpoints

### POST /translate
Dịch một đoạn văn bản đơn giản

**Request:**
```json
{
  "text": "你好世界"
}
```

**Response:**
```json
{
  "translatedText": "Xin chào thế giới"
}
```

### POST /translate2
Dịch theo format Azure Translator (được extension sử dụng)

**Request:**
```json
[
  { "Text": "你好世界" }
]
```

**Response:**
```json
[
  {
    "detectedLanguage": {
      "language": "zh",
      "score": 1.0
    },
    "translations": [
      {
        "text": "Xin chào thế giới",
        "to": "vi"
      }
    ]
  }
]
```

## Tính năng

- ✅ Tự động chuyển đổi Phồn thể → Giản thể
- ✅ Dịch Trung → Việt
- ✅ Format tương thích với Azure Translator
- ✅ Hỗ trợ CORS cho extension
- ✅ Tự động phát hiện và sử dụng bởi stv-translator

## Kết nối từ xa

### Tìm địa chỉ IP của server

**Windows:**
```cmd
ipconfig
```
Tìm "IPv4 Address" (ví dụ: 192.168.1.100)

**Linux/Mac:**
```bash
ip addr show
# hoặc
ifconfig
```

### Mở firewall (nếu cần)

**Windows:**
```cmd
netsh advfirewall firewall add rule name="VP Translator" dir=in action=allow protocol=TCP localport=5005
```

**Linux (ufw):**
```bash
sudo ufw allow 5005/tcp
```

**Docker (firewalld):**
```bash
sudo firewall-cmd --permanent --add-port=5005/tcp
sudo firewall-cmd --reload
```

### Test kết nối

Từ máy khác trong mạng, mở trình duyệt và truy cập:
```
http://<SERVER_IP>:5005/translate
```

Nếu thấy trang error hoặc response JSON → Server đang chạy OK!

## Lưu ý

- Server chạy ở port **5005** (có thể thay đổi trong `server.py` và `docker-compose.yml`)
- Đảm bảo có file `translator.py` và `ChineseConverter.py` trong cùng thư mục
- Extension sẽ tự động phát hiện server dựa trên URL pattern
- Với Docker, server bind vào `0.0.0.0` để chấp nhận kết nối từ mọi IP
- Đảm bảo firewall cho phép traffic trên port 5005

## Troubleshooting

**Không kết nối được từ xa:**
1. Kiểm tra server có đang chạy: `docker-compose ps`
2. Kiểm tra firewall đã mở port 5005
3. Kiểm tra IP address chính xác
4. Thử ping từ máy client đến server

**Docker build lỗi:**
1. Đảm bảo có đủ file: `translator.py`, `ChineseConverter.py`
2. Kiểm tra `requirements.txt` đầy đủ dependencies
3. Chạy `docker-compose build --no-cache` để build lại

**Extension không dịch:**
1. Kiểm tra console logs trong DevTools (F12)
2. Đảm bảo server URL đúng format
3. Test API trực tiếp bằng curl:
   ```bash
   curl -X POST http://<SERVER_IP>:5005/translate2 \
     -H "Content-Type: application/json" \
     -d '[{"Text":"你好"}]'
   ```