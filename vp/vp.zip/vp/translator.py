import re
import unicodedata
from QuickTranslator import load_data, convert_to_sino_vietnamese
from text_analyzer import get_analyzer

# Load data on startup
names2, names, viet_phrase, chinese_phien_am, _ = load_data()

# Get text analyzer instance
analyzer = get_analyzer()

def reload_names():
    """Reload names data from Names.txt and Names2.txt"""
    global names2, names, viet_phrase, chinese_phien_am
    names2, names, viet_phrase, chinese_phien_am, _ = load_data()
    print("[INFO] Names data reloaded successfully")

def reload_names_only():
    """
    Reload ONLY Names.txt without touching other data files (VietPhrase, ChinesePhienAm, Names2)
    This is 30-100x FASTER than reload_names() for syncing small amounts of names
    """
    global names
    import os
    import time
    from model.trie import Trie
    
    data_dir = os.path.join(os.path.dirname(__file__), 'data')
    file_path = os.path.join(data_dir, 'Names.txt')
    
    try:
        start_time = time.time()
        new_names = Trie()
        
        # Load Names.txt with same logic as load_data() (split_values=True)
        with open(file_path, 'r', encoding='utf-8') as f:
            entries = []
            for line in f:
                parts = line.strip().split('=')
                if len(parts) == 2:
                    key = unicodedata.normalize('NFC', parts[0])
                    value = unicodedata.normalize('NFC', parts[1])
                    # Split values like load_data() does
                    first_value = value.replace("|", "/").split("/")[0]
                    first_value = unicodedata.normalize('NFC', first_value)
                    entries.append((key, first_value))
        
        new_names.batch_insert(entries)
        names = new_names
        
        elapsed = time.time() - start_time
        print(f"[FAST-RELOAD] Reloaded {names.count()} names in {elapsed:.3f}s (Names.txt only)")
        return True
    except Exception as e:
        print(f"[ERROR] Failed to reload names: {e}")
        return False

# Comprehensive regex for Chinese characters (Simplified, Traditional, Extensions, Compatibility)
CHINESE_REGEX = r'[\u2E80-\u2EFF\u3000-\u303F\u31C0-\u31EF\u3200-\u32FF\u3300-\u33FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\uFE30-\uFE4F\U00020000-\U0002A6DF\U0002A700-\U0002B73F\U0002B740-\U0002B81F\U0002B820-\U0002CEAF\U0002CEB0-\U0002EBEF\U00030000-\U0003134F]'

def translate_text(text):
    """
    Translate Chinese text to Vietnamese (basic version)
    """
    # Normalize input to NFC
    text = unicodedata.normalize('NFC', text)
    
    # Check if contains Chinese
    if not re.search(CHINESE_REGEX, text):
        return text, 'und'
    
    # Extract Chinese segments
    segments = analyzer.extract_chinese_segments(text)
    
    # Translate each Chinese segment
    result_parts = []
    has_chinese = False
    
    for segment in segments:
        if segment.should_translate and segment.type == 'chinese':
            try:
                translated = convert_to_sino_vietnamese(
                    segment.text,
                    names2,
                    names,
                    viet_phrase,
                    chinese_phien_am
                )
                result_parts.append(translated)
                has_chinese = True
            except Exception as e:
                result_parts.append(segment.text)
        else:
            result_parts.append(segment.text)
    
    final_text = ''.join(result_parts)
    final_text = unicodedata.normalize('NFC', final_text)
    
    return final_text, 'zh' if has_chinese else 'und'