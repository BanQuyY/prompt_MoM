from flask import Flask, request, jsonify
from flask_cors import CORS
from translator import translate_text, reload_names, reload_names_only
from ChineseConverter import ChineseConverter
from text_analyzer import get_analyzer
from functools import lru_cache
import hashlib
import os
import unicodedata
import shutil
import threading
import time

# Initialize converter once (singleton pattern)
converter = ChineseConverter()

# Initialize text analyzer
text_analyzer = get_analyzer()

# Translation cache using LRU (Least Recently Used)
@lru_cache(maxsize=10000)
def cached_translate(text_hash, text):
    """Cache translation results to avoid redundant API calls"""
    simplified = converter.to_simplified(text)
    translated_text, lang = translate_text(simplified)
    return translated_text, lang

def get_text_hash(text):
    """Generate hash for caching"""
    return hashlib.md5(text.encode('utf-8')).hexdigest()

app = Flask(__name__)
CORS(app)

# Optimize Flask settings for production
app.config['JSON_AS_ASCII'] = False
app.config['JSON_SORT_KEYS'] = False

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    if 'text' not in data:
        return jsonify({'error': 'No text provided'}), 400

    try:
        text = data['text']
        text_hash = get_text_hash(text)
        translated_text, _ = cached_translate(text_hash, text)
        return jsonify({'translatedText': translated_text})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/translate2', methods=['POST'])
def translate2():
    post_data = request.json
    json_array = []
    
    for item in post_data:
        try:
            # Handle both "text" and "Text" keys
            text = item.get('text') or item.get('Text')
            if not text:
                raise KeyError("No 'text' or 'Text' field found in request")
            
            # Use cached translation
            text_hash = get_text_hash(text)
            translated_text, lang = cached_translate(text_hash, text)
            
            json_array.append({
                "detectedLanguage": {
                    "language": lang,
                    "score": 1.0
                },
                "translations": [
                    {
                        "text": translated_text.strip(),
                        "to": "vi"
                    }
                ]
            })
        except Exception as e:
            json_array.append({
                "error": str(e)
            })
            
    return jsonify(json_array)

@app.route('/cache/clear', methods=['POST'])
def clear_cache():
    """Clear translation cache"""
    cached_translate.cache_clear()
    return jsonify({'message': 'Cache cleared', 'status': 'success'})

@app.route('/cache/info', methods=['GET'])
def cache_info():
    """Get cache statistics"""
    info = cached_translate.cache_info()
    return jsonify({
        'hits': info.hits,
        'misses': info.misses,
        'size': info.currsize,
        'maxsize': info.maxsize,
        'hit_rate': f"{(info.hits / (info.hits + info.misses) * 100):.2f}%" if (info.hits + info.misses) > 0 else "0%"
    })

@app.route('/names', methods=['GET'])
def get_names():
    """
    Get names data from Names.txt and Names2.txt
    Returns combined names in format: Chinese=Vietnamese
    """
    try:
        names_data = []
        data_dir = os.path.join(os.path.dirname(__file__), 'data')
        
        # Read Names2.txt first (higher priority)
        names2_path = os.path.join(data_dir, 'Names2.txt')
        if os.path.exists(names2_path):
            try:
                with open(names2_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        # Skip empty lines and BOM
                        if line and '=' in line and not line.startswith('\ufeff'):
                            # Normalize to NFC
                            line = unicodedata.normalize('NFC', line)
                            names_data.append(line)
            except Exception as e:
                print(f"Error reading Names2.txt: {e}")
        
        # Read Names.txt
        names_path = os.path.join(data_dir, 'Names.txt')
        if os.path.exists(names_path):
            try:
                with open(names_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        # Skip empty lines and BOM
                        if line and '=' in line and not line.startswith('\ufeff'):
                            # Normalize to NFC
                            line = unicodedata.normalize('NFC', line)
                            # Remove alternatives (|, /) to match VP behavior (split_values=True)
                            parts = line.split('=')
                            if len(parts) == 2:
                                key = parts[0].strip()
                                value = parts[1].strip()
                                # Take first value if multiple alternatives exist
                                first_value = value.replace("|", "/").split("/")[0].strip()
                                names_data.append(f"{key}={first_value}")
            except Exception as e:
                print(f"Error reading Names.txt: {e}")
        
        # Remove duplicates while preserving order (Names2 has priority)
        seen = set()
        unique_names = []
        for name in names_data:
            # Use Chinese name (before =) as key for deduplication
            key = name.split('=')[0] if '=' in name else name
            if key not in seen:
                seen.add(key)
                unique_names.append(name)
        
        return jsonify({
            'status': 'success',
            'names': '\n'.join(unique_names),
            'count': len(unique_names),
            'message': f'Loaded {len(unique_names)} names from Names.txt and Names2.txt'
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e),
            'names': '',
            'count': 0
        }), 500

@app.route('/names', methods=['POST'])
def update_names():
    """Update Names.txt with data from SillyTavern UI (OPTIMIZED x3-x5 faster + RELIABLE)"""
    start_time = time.time()
    
    try:
        data = request.get_json()
        
        if not data or 'names' not in data:
            return jsonify({
                'status': 'error',
                'error': 'Missing names data'
            }), 400
        
        names_content = data['names']
        
        # Quick validation - reject if empty
        if not names_content or not names_content.strip():
            return jsonify({
                'status': 'error',
                'error': 'Empty names data'
            }), 400
        
        data_dir = os.path.join(os.path.dirname(__file__), 'data')
        names_file = os.path.join(data_dir, 'Names.txt')
        
        # ✅ OPTIMIZATION 1: Skip Unicode normalization (UTF-8 handles it)
        # Loại bỏ normalize để tiết kiệm ~30-40% thời gian với file lớn
        # names_content = unicodedata.normalize('NFC', names_content)
        
        # ✅ OPTIMIZATION 2: Async backup in background thread (non-blocking)
        # Backup chạy song song, không chặn việc ghi file chính
        if os.path.exists(names_file):
            backup_file = os.path.join(data_dir, 'Names.txt.backup')
            def async_backup():
                try:
                    shutil.copy(names_file, backup_file)
                    print(f"[ASYNC] Backup completed in background")
                except Exception as e:
                    print(f"[ASYNC] Backup failed: {e}")
            
            # Chạy backup trong background thread
            threading.Thread(target=async_backup, daemon=True).start()
        
        # ✅ OPTIMIZATION 3: Ultra-fast buffered write (64KB buffer)
        # Tăng buffer từ 8KB lên 64KB để giảm số lần I/O
        with open(names_file, 'w', encoding='utf-8', buffering=65536) as f:
            f.write(names_content)
        
        # ✅ OPTIMIZATION 4: Fast line counting
        valid_count = sum(1 for line in names_content.split('\n') if '=' in line and line.strip())
        
        write_time = time.time() - start_time
        print(f"[FAST] Wrote {valid_count} names to Names.txt in {write_time:.3f}s")
        
        # ✅ OPTIMIZATION 5: SIÊU NHANH - CHỈ reload Names.txt thay vì reload CẢ 4 files
        # Chỉ reload Names.txt (không reload VietPhrase/ChinesePhienAm/Names2) → NHANH 30-100 lần
        reload_start = time.time()
        reload_names_only()  # CHỈ reload Names.txt (~0.1-0.3s thay vì 10s)
        reload_time = time.time() - reload_start
        print(f"[ULTRA-FAST] Reloaded Names.txt only in {reload_time:.3f}s")
        
        # Clear cache có thể async (không ảnh hưởng đến dịch ngay lập tức)
        def async_clear_cache():
            try:
                cached_translate.cache_clear()
                print(f"[ASYNC] Translation cache cleared")
            except Exception as e:
                print(f"[ASYNC] Cache clear failed: {e}")
        
        threading.Thread(target=async_clear_cache, daemon=True).start()
        
        total_time = time.time() - start_time
        
        return jsonify({
            'status': 'success',
            'message': f'Fast sync: {valid_count} entries in {total_time:.3f}s',
            'count': valid_count,
            'cache_cleared': True,
            'sync_time': f'{total_time:.3f}s',
            'reload_time': f'{reload_time:.3f}s',
            'optimized': True
        })
        
    except IOError as e:
        print(f"[ERROR] File I/O error: {str(e)}")
        return jsonify({
            'status': 'error',
            'error': f'File operation failed: {str(e)}'
        }), 500
    except Exception as e:
        print(f"[ERROR] Failed to update Names.txt: {str(e)}")
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

@app.route('/test-translate', methods=['POST'])
def test_translate():
    """Test translation with specific text"""
    try:
        data = request.json
        text = data.get('text', '林七')
        
        # Import translator module to access loaded names
        from translator import names, names2
        
        # Try find_longest_prefix instead of search
        names_match, names_value = names.find_longest_prefix(text)
        names2_match, names2_value = names2.find_longest_prefix(text)
        
        # Check if 林七 is in names or names2
        result = {
            'input': text,
            'names_match': names_match,
            'names_value': names_value,
            'names2_match': names2_match,
            'names2_value': names2_value,
            'names_count': names.count(),
            'names2_count': names2.count()
        }
        
        # Try to translate
        translated, lang = translate_text(text)
        result['translated'] = translated
        result['detected_lang'] = lang
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/reload-names', methods=['POST'])
def reload_names_endpoint():
    """Reload names data manually"""
    try:
        reload_names()
        cached_translate.cache_clear()
        
        from translator import names, names2
        
        return jsonify({
            'status': 'success',
            'message': 'Names data reloaded and cache cleared',
            'names_count': names.count(),
            'names2_count': names2.count()
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'VP Translation Server'})

if __name__ == '__main__':
    # Use threaded mode for better concurrency
    app.run(host='0.0.0.0', port=5005, debug=False, threaded=True)