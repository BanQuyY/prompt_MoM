"""
Text Analyzer Module
Phân tích văn bản để phát hiện và phân loại các phần:
- Code (các đoạn mã lập trình)
- Tiếng Trung (cần dịch)
- Tiếng Anh/Việt/Các ngôn ngữ khác (giữ nguyên)
"""

import re
import unicodedata

class TextSegment:
    """Đại diện cho một đoạn văn bản"""
    def __init__(self, text, segment_type, should_translate=False):
        self.text = text
        self.type = segment_type  # 'chinese', 'code', 'english', 'vietnamese', 'other'
        self.should_translate = should_translate
    
    def __repr__(self):
        return f"TextSegment(type={self.type}, translate={self.should_translate}, text='{self.text[:20]}...')"


class TextAnalyzer:
    """Phân tích và phân loại văn bản"""
    
    # Regex patterns - bao gồm chữ Hán, dấu câu TQ, số, chữ Latin và tiếng Việt
    # Chữ Hán CJK + Dấu câu tiếng Trung + Số + Chữ cái (a-z, A-Z) + Tiếng Việt
    CHINESE_PATTERN = re.compile(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef0-9a-zA-ZàáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ]+')
    VIETNAMESE_PATTERN = re.compile(r'[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]', re.IGNORECASE)
    
    # Code patterns
    CODE_PATTERNS = [
        r'^\s*[\w_]+\s*[:=]\s*.+$',  # Variable assignment: var = value, key: value
        r'^\s*def\s+\w+\s*\(',  # Python function
        r'^\s*class\s+\w+',  # Class definition
        r'^\s*import\s+',  # Import statement
        r'^\s*from\s+\w+\s+import',  # From import
        r'^\s*function\s+\w+\s*\(',  # JavaScript function
        r'^\s*const\s+\w+',  # JavaScript const
        r'^\s*let\s+\w+',  # JavaScript let
        r'^\s*var\s+\w+',  # JavaScript var
        r'[\{\}\[\];]',  # Brackets and semicolons
        r'^\s*//.*$',  # Single line comment
        r'^\s*/\*.*\*/$',  # Multi-line comment (single line)
        r'<[^>]+>',  # HTML/XML tags
        r'^\s*#.*$',  # Python/Shell comment
        r'^\s*\$\w+',  # Shell variable
        r'=>',  # Arrow function
        r'\(\s*\)\s*=>',  # Arrow function
        r'^\s*[\w_]+\s*\(.*\)\s*\{',  # Function with block
        r'^\s*if\s*\(',  # If statement
        r'^\s*for\s*\(',  # For loop
        r'^\s*while\s*\(',  # While loop
        r'^\s*return\s+',  # Return statement
        r'(?:async|await|yield)',  # Async keywords
        r'\w+\.\w+\(',  # Method call
        r'(?:true|false|null|undefined|None|True|False)',  # Boolean/null literals
        r'^\s*@\w+',  # Decorator
        r'(?:\+\+|--)',  # Increment/decrement
        r'(?:&&|\|\||==|===|!=|!==|<=|>=)',  # Logical operators
    ]
    
    # English common words (để phát hiện văn bản tiếng Anh)
    ENGLISH_COMMON_WORDS = {
        'the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'i',
        'it', 'for', 'not', 'on', 'with', 'he', 'as', 'you', 'do', 'at',
        'this', 'but', 'his', 'by', 'from', 'they', 'we', 'say', 'her', 'she',
        'or', 'an', 'will', 'my', 'one', 'all', 'would', 'there', 'their', 'what'
    }
    
    def __init__(self):
        self.compiled_code_patterns = [re.compile(pattern, re.MULTILINE) for pattern in self.CODE_PATTERNS]
    
    def is_code(self, text):
        """Kiểm tra xem văn bản có phải là code không"""
        # Kiểm tra các pattern code
        for pattern in self.compiled_code_patterns:
            if pattern.search(text):
                return True
        
        # Kiểm tra tỷ lệ ký tự đặc biệt (code thường có nhiều ký tự đặc biệt)
        special_chars = len(re.findall(r'[{}\[\]();:=<>!&|+\-*/\\]', text))
        if len(text) > 0 and special_chars / len(text) > 0.15:
            return True
        
        return False
    
    def contains_chinese(self, text):
        """Kiểm tra xem văn bản có chứa tiếng Trung không"""
        return bool(self.CHINESE_PATTERN.search(text))
    
    def contains_vietnamese(self, text):
        """Kiểm tra xem văn bản có chứa tiếng Việt không"""
        return bool(self.VIETNAMESE_PATTERN.search(text))
    
    def is_english(self, text):
        """Kiểm tra xem văn bản có phải tiếng Anh không"""
        # Chuyển về lowercase và tách từ
        words = re.findall(r'\b[a-z]+\b', text.lower())
        if not words:
            return False
        
        # Kiểm tra số lượng từ tiếng Anh phổ biến
        common_count = sum(1 for word in words if word in self.ENGLISH_COMMON_WORDS)
        
        # Nếu > 30% là từ tiếng Anh phổ biến thì coi là tiếng Anh
        return len(words) > 0 and (common_count / len(words)) > 0.3
    
    def extract_chinese_segments(self, text):
        """
        Trích xuất các đoạn tiếng Trung từ văn bản hỗn hợp
        Returns: list of TextSegment
        """
        segments = []
        last_end = 0
        
        for match in self.CHINESE_PATTERN.finditer(text):
            # Phần không phải tiếng Trung trước match
            if match.start() > last_end:
                non_chinese_text = text[last_end:match.start()]
                segments.append(TextSegment(
                    text=non_chinese_text,
                    segment_type='other',
                    should_translate=False
                ))
            
            # Phần tiếng Trung
            chinese_text = match.group()
            segments.append(TextSegment(
                text=chinese_text,
                segment_type='chinese',
                should_translate=True
            ))
            
            last_end = match.end()
        
        # Phần còn lại (nếu có)
        if last_end < len(text):
            remaining_text = text[last_end:]
            segments.append(TextSegment(
                text=remaining_text,
                segment_type='other',
                should_translate=False
            ))
        
        return segments
    
    def analyze_text(self, text):
        """
        Phân tích văn bản và quyết định phần nào cần dịch
        Returns: list of TextSegment
        """
        # Normalize text
        text = unicodedata.normalize('NFC', text)
        
        # Nếu là code, không dịch
        if self.is_code(text):
            return [TextSegment(text=text, segment_type='code', should_translate=False)]
        
        # Nếu không chứa tiếng Trung, không dịch
        if not self.contains_chinese(text):
            # Phân loại thêm
            if self.contains_vietnamese(text):
                segment_type = 'vietnamese'
            elif self.is_english(text):
                segment_type = 'english'
            else:
                segment_type = 'other'
            
            return [TextSegment(text=text, segment_type=segment_type, should_translate=False)]
        
        # Nếu chứa tiếng Trung, trích xuất các đoạn tiếng Trung
        return self.extract_chinese_segments(text)
    
    def analyze_lines(self, text):
        """
        Phân tích văn bản theo từng dòng (tốt hơn cho văn bản dài)
        Returns: list of TextSegment
        """
        lines = text.split('\n')
        all_segments = []
        
        for i, line in enumerate(lines):
            # Phân tích từng dòng
            line_segments = self.analyze_text(line)
            all_segments.extend(line_segments)
            
            # Thêm newline nếu không phải dòng cuối
            if i < len(lines) - 1:
                all_segments.append(TextSegment(text='\n', segment_type='newline', should_translate=False))
        
        return all_segments
    
    def should_translate_text(self, text):
        """
        Kiểm tra nhanh xem văn bản có cần dịch không
        Returns: (should_translate: bool, reason: str)
        """
        # Normalize
        text = unicodedata.normalize('NFC', text)
        
        # Kiểm tra code
        if self.is_code(text):
            return False, 'code'
        
        # Kiểm tra tiếng Trung
        if not self.contains_chinese(text):
            if self.contains_vietnamese(text):
                return False, 'vietnamese'
            elif self.is_english(text):
                return False, 'english'
            else:
                return False, 'no_chinese'
        
        return True, 'contains_chinese'


# Singleton instance
_analyzer_instance = None

def get_analyzer():
    """Get or create TextAnalyzer singleton instance"""
    global _analyzer_instance
    if _analyzer_instance is None:
        _analyzer_instance = TextAnalyzer()
    return _analyzer_instance