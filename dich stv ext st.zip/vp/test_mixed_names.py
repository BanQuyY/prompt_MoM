#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script để kiểm tra việc dịch các tên hỗn hợp (có cả tiếng Trung và Latin)
"""

from translator import translate_text

def test_mixed_names():
    """Test các tên hỗn hợp"""
    test_cases = [
        ("亚anan很高兴", "亚anan", "Á Nam"),  # Trung + Latin
        ("Katsu君在这里", "Katsu君", "Katsu-kun"),  # Latin + Trung
        ("林x七来了", "林x七", "LâmxThất"),  # Trung + Latin + Trung
        ("浅见亚美是医生", "浅见亚美", "Asami Ami"),  # Tên Nhật thông thường
        ("苏晚晴和亚anan", "苏晚晴", "Tô Vãn Tình"),  # Tên thông thường
    ]
    
    print("=" * 60)
    print("KẾT QUẢ KIỂM TRA TÊN HỖN HỢP")
    print("=" * 60)
    
    passed = 0
    failed = 0
    
    for sentence, target_name, expected_translation in test_cases:
        result, lang = translate_text(sentence)
        
        # Kiểm tra xem bản dịch mong đợi có trong kết quả không
        if expected_translation in result:
            status = "✓ PASS"
            passed += 1
        else:
            status = "✗ FAIL"
            failed += 1
        
        print(f"\n{status}")
        print(f"  Input:    {sentence}")
        print(f"  Tên test: {target_name} → {expected_translation}")
        print(f"  Output:   {result}")
    
    print("\n" + "=" * 60)
    print(f"TỔNG KẾT: {passed} passed, {failed} failed")
    print("=" * 60)
    
    return failed == 0

if __name__ == "__main__":
    success = test_mixed_names()
    exit(0 if success else 1)