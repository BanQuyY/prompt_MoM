import { Buffer } from 'node:buffer';
import fetch from 'node-fetch';
import express from 'express';
import { speak, languages } from 'google-translate-api-x';
import crypto from 'node:crypto';
import util from 'node:util';
import urlJoin from 'url-join';
import lodash from 'lodash';

import { readSecret, SECRET_KEYS } from './secrets.js';
import * as constants from '../constants.js';
import { delay, getConfigValue, trimTrailingSlash } from '../util.js';

const { GEMINI_SAFETY, VERTEX_SAFETY } = constants;

const API_MAKERSUITE = 'https://generativelanguage.googleapis.com';
const API_VERTEX_AI = 'https://us-central1-aiplatform.googleapis.com';

function createWavHeader(dataSize, sampleRate, numChannels = 1, bitsPerSample = 16) {
    const header = Buffer.alloc(44);
    header.write('RIFF', 0);
    header.writeUInt32LE(36 + dataSize, 4);
    header.write('WAVE', 8);
    header.write('fmt ', 12);
    header.writeUInt32LE(16, 16);
    header.writeUInt16LE(1, 20);
    header.writeUInt16LE(numChannels, 22);
    header.writeUInt32LE(sampleRate, 24);
    header.writeUInt32LE(sampleRate * numChannels * bitsPerSample / 8, 28);
    header.writeUInt16LE(numChannels * bitsPerSample / 8, 32);
    header.writeUInt16LE(bitsPerSample, 34);
    header.write('data', 36);
    header.writeUInt32LE(dataSize, 40);
    return header;
}

function createCompleteWavFile(pcmData, sampleRate) {
    const header = createWavHeader(pcmData.length, sampleRate);
    return Buffer.concat([header, pcmData]);
}

// Vertex AI authentication helper functions
export async function getVertexAIAuth(request) {
    const authMode = request.body.vertexai_auth_mode || 'express';

    if (request.body.reverse_proxy) {
        return {
            authHeader: `Bearer ${request.body.proxy_password}`,
            authType: 'proxy',
        };
    }

    if (authMode === 'express') {
        const apiKey = readSecret(request.user.directories, SECRET_KEYS.VERTEXAI);
        if (apiKey) {
            return {
                authHeader: `Bearer ${apiKey}`,
                authType: 'express',
            };
        }
        throw new Error('API key is required for Vertex AI Express mode');
    } else if (authMode === 'full') {
        // Get service account JSON from backend storage
        const serviceAccountJson = readSecret(request.user.directories, SECRET_KEYS.VERTEXAI_SERVICE_ACCOUNT);

        if (serviceAccountJson) {
            try {
                const serviceAccount = JSON.parse(serviceAccountJson);
                const jwtToken = await generateJWTToken(serviceAccount);
                const accessToken = await getAccessToken(jwtToken);
                return {
                    authHeader: `Bearer ${accessToken}`,
                    authType: 'full',
                };
            } catch (error) {
                console.error('Failed to authenticate with service account:', error);
                throw new Error(`Service account authentication failed: ${error.message}`);
            }
        }
        throw new Error('Service Account JSON is required for Vertex AI Full mode');
    }

    throw new Error(`Unsupported Vertex AI authentication mode: ${authMode}`);
}

/**
 * Generates a JWT token for Google Cloud authentication using service account credentials.
 * @param {object} serviceAccount Service account JSON object
 * @returns {Promise<string>} JWT token
 */
export async function generateJWTToken(serviceAccount) {
    const now = Math.floor(Date.now() / 1000);
    const expiry = now + 3600; // 1 hour

    const header = {
        alg: 'RS256',
        typ: 'JWT',
    };

    const payload = {
        iss: serviceAccount.client_email,
        scope: 'https://www.googleapis.com/auth/cloud-platform',
        aud: 'https://oauth2.googleapis.com/token',
        iat: now,
        exp: expiry,
    };

    const headerBase64 = Buffer.from(JSON.stringify(header)).toString('base64url');
    const payloadBase64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
    const signatureInput = `${headerBase64}.${payloadBase64}`;

    // Create signature using private key
    const sign = crypto.createSign('RSA-SHA256');
    sign.update(signatureInput);
    const signature = sign.sign(serviceAccount.private_key, 'base64url');

    return `${signatureInput}.${signature}`;
}

export async function getAccessToken(jwtToken) {
    const response = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            assertion: jwtToken,
        }),
    });

    if (!response.ok) {
        const error = await response.text();
        throw new Error(`Failed to get access token: ${error}`);
    }

    /** @type {any} */
    const data = await response.json();
    return data.access_token;
}

/**
 * Extracts the project ID from a Service Account JSON object.
 * @param {object} serviceAccount Service account JSON object
 * @returns {string} Project ID
 * @throws {Error} If project ID is not found in the service account
 */
export function getProjectIdFromServiceAccount(serviceAccount) {
    if (!serviceAccount || typeof serviceAccount !== 'object') {
        throw new Error('Invalid service account object');
    }

    const projectId = serviceAccount.project_id;
    if (!projectId || typeof projectId !== 'string') {
        throw new Error('Project ID not found in service account JSON');
    }

    return projectId;
}

/**
 * Generates Google API URL and headers based on request configuration
 * @param {express.Request} request Express request object
 * @param {string} model Model name to use
 * @param {string} endpoint API endpoint (default: 'generateContent')
 * @returns {Promise<{url: string, headers: object, apiName: string, baseUrl: string, safetySettings: object[]}>} URL, headers, and API name
 */
export async function getGoogleApiConfig(request, model, endpoint = 'generateContent') {
    const useVertexAi = request.body.api === 'vertexai';
    const region = request.body.vertexai_region || 'us-central1';
    const apiName = useVertexAi ? 'Google Vertex AI' : 'Google AI Studio';
    const safetySettings = [...GEMINI_SAFETY, ...(useVertexAi ? VERTEX_SAFETY : [])];

    let url;
    let baseUrl;
    let headers = {
        'Content-Type': 'application/json',
    };

    if (useVertexAi) {
        // Get authentication for Vertex AI
        const { authHeader, authType } = await getVertexAIAuth(request);

        if (authType === 'express') {
            // Express mode: use API key parameter
            const keyParam = authHeader.replace('Bearer ', '');
            const projectId = request.body.vertexai_express_project_id;
            baseUrl = region === 'global'
                ? 'https://aiplatform.googleapis.com/v1'
                : `https://${region}-aiplatform.googleapis.com/v1`;
            url = projectId
                ? `${baseUrl}/projects/${projectId}/locations/${region}/publishers/google/models/${model}:${endpoint}`
                : `${baseUrl}/publishers/google/models/${model}:${endpoint}`;
            headers['x-goog-api-key'] = keyParam;
        } else if (authType === 'full') {
            // Full mode: use project-specific URL with Authorization header
            // Get project ID from Service Account JSON
            const serviceAccountJson = readSecret(request.user.directories, SECRET_KEYS.VERTEXAI_SERVICE_ACCOUNT);
            if (!serviceAccountJson) {
                throw new Error('Vertex AI Service Account JSON is missing.');
            }

            let projectId;
            try {
                const serviceAccount = JSON.parse(serviceAccountJson);
                projectId = getProjectIdFromServiceAccount(serviceAccount);
            } catch (error) {
                throw new Error('Failed to extract project ID from Service Account JSON.');
            }
            // Handle global region differently - no region prefix in hostname
            baseUrl = region === 'global'
                ? 'https://aiplatform.googleapis.com/v1'
                : `https://${region}-aiplatform.googleapis.com/v1`;
            url = `${baseUrl}/projects/${projectId}/locations/${region}/publishers/google/models/${model}:${endpoint}`;
            headers['Authorization'] = authHeader;
        } else {
            // Proxy mode: use Authorization header
            const apiUrl = trimTrailingSlash(request.body.reverse_proxy || API_VERTEX_AI);
            baseUrl = `${apiUrl}/v1`;
            url = `${baseUrl}/publishers/google/models/${model}:${endpoint}`;
            headers['Authorization'] = authHeader;
        }
    } else {
        // Google AI Studio
        const apiKey = request.body.reverse_proxy ? request.body.proxy_password : readSecret(request.user.directories, SECRET_KEYS.MAKERSUITE);
        const apiUrl = trimTrailingSlash(request.body.reverse_proxy || API_MAKERSUITE);
        const apiVersion = getConfigValue('gemini.apiVersion', 'v1beta');
        baseUrl = `${apiUrl}/${apiVersion}`;
        url = `${baseUrl}/models/${model}:${endpoint}`;
        headers['x-goog-api-key'] = apiKey;
    }

    return { url, headers, apiName, baseUrl, safetySettings };
}

export const router = express.Router();

router.post('/caption-image', async (request, response) => {
    try {
        const mimeType = request.body.image.split(';')[0].split(':')[1];
        const base64Data = request.body.image.split(',')[1];
        const model = request.body.model || 'gemini-2.0-flash';
        const { url, headers, apiName, safetySettings } = await getGoogleApiConfig(request, model);

        const body = {
            contents: [{
                role: 'user',
                parts: [
                    { text: request.body.prompt },
                    {
                        inlineData: {
                            mimeType: mimeType,
                            data: base64Data,
                        },
                    }],
            }],
            safetySettings: safetySettings,
        };

        console.debug(`${apiName} captioning request`, model, body);

        const result = await fetch(url, {
            body: JSON.stringify(body),
            method: 'POST',
            headers: headers,
        });

        if (!result.ok) {
            const error = await result.json();
            console.error(`${apiName} API returned error: ${result.status} ${result.statusText}`, error);
            return response.status(500).send({ error: true });
        }

        /** @type {any} */
        const data = await result.json();
        console.info(`${apiName} captioning response`, data);

        const candidates = data?.candidates;
        if (!candidates) {
            return response.status(500).send('No candidates found, image was most likely filtered.');
        }

        const caption = candidates[0].content.parts[0].text;
        if (!caption) {
            return response.status(500).send('No caption found');
        }

        return response.json({ caption });
    } catch (error) {
        console.error(error);
        response.status(500).send('Internal server error');
    }
});

router.post('/list-voices', (_, response) => {
    return response.json(languages);
});

router.post('/generate-voice', async (request, response) => {
    try {
        const text = request.body.text;
        const voice = request.body.voice ?? 'en';

        const result = await speak(text, { to: voice, forceBatch: false });
        const buffer = Array.isArray(result)
            ? Buffer.concat(result.map(x => new Uint8Array(Buffer.from(x.toString(), 'base64'))))
            : Buffer.from(result.toString(), 'base64');

        response.setHeader('Content-Type', 'audio/mpeg');
        return response.send(buffer);
    } catch (error) {
        console.error('Google Translate TTS generation failed', error);
        response.status(500).send('Internal server error');
    }
});

router.post('/list-native-voices', async (_, response) => {
    try {
        // Hardcoded Gemini native TTS voices from official documentation
        // Source: https://ai.google.dev/gemini-api/docs/speech-generation#voices
        const voices = [
            { name: 'Zephyr', voice_id: 'Zephyr', lang: 'en-US', description: 'Bright' },
            { name: 'Puck', voice_id: 'Puck', lang: 'en-US', description: 'Upbeat' },
            { name: 'Charon', voice_id: 'Charon', lang: 'en-US', description: 'Informative' },
            { name: 'Kore', voice_id: 'Kore', lang: 'en-US', description: 'Firm' },
            { name: 'Fenrir', voice_id: 'Fenrir', lang: 'en-US', description: 'Excitable' },
            { name: 'Leda', voice_id: 'Leda', lang: 'en-US', description: 'Youthful' },
            { name: 'Orus', voice_id: 'Orus', lang: 'en-US', description: 'Firm' },
            { name: 'Aoede', voice_id: 'Aoede', lang: 'en-US', description: 'Breezy' },
            { name: 'Callirhoe', voice_id: 'Callirhoe', lang: 'en-US', description: 'Easy-going' },
            { name: 'Autonoe', voice_id: 'Autonoe', lang: 'en-US', description: 'Bright' },
            { name: 'Enceladus', voice_id: 'Enceladus', lang: 'en-US', description: 'Breathy' },
            { name: 'Iapetus', voice_id: 'Iapetus', lang: 'en-US', description: 'Clear' },
            { name: 'Umbriel', voice_id: 'Umbriel', lang: 'en-US', description: 'Easy-going' },
            { name: 'Algieba', voice_id: 'Algieba', lang: 'en-US', description: 'Smooth' },
            { name: 'Despina', voice_id: 'Despina', lang: 'en-US', description: 'Smooth' },
            { name: 'Erinome', voice_id: 'Erinome', lang: 'en-US', description: 'Clear' },
            { name: 'Algenib', voice_id: 'Algenib', lang: 'en-US', description: 'Gravelly' },
            { name: 'Rasalgethi', voice_id: 'Rasalgethi', lang: 'en-US', description: 'Informative' },
            { name: 'Laomedeia', voice_id: 'Laomedeia', lang: 'en-US', description: 'Upbeat' },
            { name: 'Achernar', voice_id: 'Achernar', lang: 'en-US', description: 'Soft' },
            { name: 'Alnilam', voice_id: 'Alnilam', lang: 'en-US', description: 'Firm' },
            { name: 'Schedar', voice_id: 'Schedar', lang: 'en-US', description: 'Even' },
            { name: 'Gacrux', voice_id: 'Gacrux', lang: 'en-US', description: 'Mature' },
            { name: 'Pulcherrima', voice_id: 'Pulcherrima', lang: 'en-US', description: 'Forward' },
            { name: 'Achird', voice_id: 'Achird', lang: 'en-US', description: 'Friendly' },
            { name: 'Zubenelgenubi', voice_id: 'Zubenelgenubi', lang: 'en-US', description: 'Casual' },
            { name: 'Vindemiatrix', voice_id: 'Vindemiatrix', lang: 'en-US', description: 'Gentle' },
            { name: 'Sadachbia', voice_id: 'Sadachbia', lang: 'en-US', description: 'Lively' },
            { name: 'Sadaltager', voice_id: 'Sadaltager', lang: 'en-US', description: 'Knowledgeable' },
            { name: 'Sulafat', voice_id: 'Sulafat', lang: 'en-US', description: 'Warm' },
        ];
        return response.json({ voices });
    } catch (error) {
        console.error('Failed to return Google TTS voices:', error);
        response.sendStatus(500);
    }
});

router.post('/generate-native-tts', async (request, response) => {
    try {
        const { text, voice, model } = request.body;
        const { url, headers, apiName, safetySettings } = await getGoogleApiConfig(request, model);

        console.debug(`${apiName} TTS request`, { model, text, voice });

        const requestBody = {
            contents: [{
                role: 'user',
                parts: [{ text: text }],
            }],
            generationConfig: {
                responseModalities: ['AUDIO'],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: {
                            voiceName: voice,
                        },
                    },
                },
            },
            safetySettings: safetySettings,
        };

        const result = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(requestBody),
        });

        if (!result.ok) {
            const errorText = await result.text();
            console.error(`${apiName} TTS API error: ${result.status} ${result.statusText}`, errorText);
            const errorMessage = JSON.parse(errorText).error?.message || 'TTS generation failed.';
            return response.status(result.status).json({ error: errorMessage });
        }

        /** @type {any} */
        const data = await result.json();
        const audioPart = data?.candidates?.[0]?.content?.parts?.[0];
        const audioData = audioPart?.inlineData?.data;
        const mimeType = audioPart?.inlineData?.mimeType;

        if (!audioData) {
            return response.status(500).json({ error: 'No audio data found in response' });
        }

        const audioBuffer = Buffer.from(audioData, 'base64');

        //If the audio is raw PCM, wrap it in a WAV header and send it.
        if (mimeType && mimeType.toLowerCase().includes('audio/l16')) {
            const rateMatch = mimeType.match(/rate=(\d+)/);
            const sampleRate = rateMatch ? parseInt(rateMatch[1], 10) : 24000;
            const pcmData = audioBuffer;

            // Create a complete, playable WAV file buffer.
            const wavBuffer = createCompleteWavFile(pcmData, sampleRate);

            // Send the WAV file directly to the browser. This is much faster.
            response.setHeader('Content-Type', 'audio/wav');
            return response.send(wavBuffer);
        }

        // Fallback for any other audio format Google might send in the future.
        response.setHeader('Content-Type', mimeType || 'application/octet-stream');
        response.send(audioBuffer);
    } catch (error) {
        console.error('Google TTS generation failed:', error);
        if (!response.headersSent) {
            return response.status(500).json({ error: 'Internal server error during TTS generation' });
        }
        return response.end();
    }
});

router.post('/generate-image', async (request, response) => {
    try {
        const model = request.body.model || 'imagen-3.0-generate-002';
        const { url, headers, apiName } = await getGoogleApiConfig(request, model, 'predict');

        // AI Studio is stricter than Vertex AI.
        const isVertex = request.body.api === 'vertexai';
        // Is it even worth it?
        const isDeprecated = model.startsWith('imagegeneration');

        const requestBody = {
            instances: [{
                prompt: request.body.prompt || '',
            }],
            parameters: {
                sampleCount: 1,
                seed: isVertex ? Number(request.body.seed ?? Math.floor(Math.random() * 1000000)) : undefined,
                enhancePrompt: isVertex ? Boolean(request.body.enhance ?? false) : undefined,
                negativePrompt: isVertex ? (request.body.negative_prompt || undefined) : undefined,
                aspectRatio: String(request.body.aspect_ratio || '1:1'),
                personGeneration: !isDeprecated ? 'allow_all' : undefined,
                language: isVertex ? 'auto' : undefined,
                safetySetting: !isDeprecated ? (isVertex ? 'block_only_high' : 'block_low_and_above') : undefined,
                addWatermark: isVertex ? false : undefined,
                outputOptions: {
                    mimeType: 'image/jpeg',
                    compressionQuality: 100,
                },
            },
        };

        console.debug(`${apiName} image generation request:`, model, requestBody);

        const result = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(requestBody),
        });

        if (!result.ok) {
            const errorText = await result.text();
            console.warn(`${apiName} image generation error: ${result.status} ${result.statusText}`, errorText);
            return response.status(500).send('Image generation request failed');
        }

        /** @type {any} */
        const data = await result.json();
        const imagePart = data?.predictions?.[0]?.bytesBase64Encoded;

        if (!imagePart) {
            console.warn(`${apiName} image generation error: No image data found in response`);
            return response.status(500).send('No image data found in response');
        }

        return response.send({ image: imagePart });
    } catch (error) {
        console.error('Google Image generation failed:', error);
        if (!response.headersSent) {
            return response.sendStatus(500);
        }
        return response.end();
    }
});

router.post('/generate-video', async (request, response) => {
    try {
        const controller = new AbortController();
        request.socket.removeAllListeners('close');
        request.socket.on('close', function () {
            controller.abort();
        });

        const model = request.body.model || 'veo-3.1-generate-preview';
        const { url, headers, apiName, baseUrl } = await getGoogleApiConfig(request, model, 'predictLongRunning');
        const useVertexAi = request.body.api === 'vertexai';

        const isVeo3 = /veo-3/.test(model);
        const lowerBound = isVeo3 ? 4 : 5;
        const upperBound = isVeo3 ? 8 : 8;

        const requestBody = {
            instances: [{
                prompt: String(request.body.prompt || ''),
            }],
            parameters: {
                negativePrompt: String(request.body.negative_prompt || ''),
                durationSeconds: lodash.clamp(Number(request.body.seconds || 6), lowerBound, upperBound),
                aspectRatio: String(request.body.aspect_ratio || '16:9'),
                personGeneration: 'allow_all',
                seed: isVeo3 ? Number(request.body.seed ?? Math.floor(Math.random() * 1000000)) : undefined,
            },
        };

        console.debug(`${apiName} video generation request:`, model, requestBody);
        const videoJobResponse = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(requestBody),
        });

        if (!videoJobResponse.ok) {
            const errorText = await videoJobResponse.text();
            console.warn(`${apiName} video generation error: ${videoJobResponse.status} ${videoJobResponse.statusText}`, errorText);
            return response.status(500).send('Video generation request failed');
        }

        /** @type {any} */
        const videoJobData = await videoJobResponse.json();
        const videoJobName = videoJobData?.name;

        if (!videoJobName) {
            console.warn(`${apiName} video generation error: No job name found in response`);
            return response.status(500).send('No video job name found in response');
        }

        console.debug(`${apiName} video job name:`, videoJobName);

        for (let attempt = 0; attempt < 30; attempt++) {
            if (controller.signal.aborted) {
                console.info(`${apiName} video generation aborted by client`);
                return response.status(500).send('Video generation aborted by client');
            }

            await delay(5000 + attempt * 1000);

            if (useVertexAi) {
                const { url: pollUrl, headers: pollHeaders } = await getGoogleApiConfig(request, model, 'fetchPredictOperation');

                const pollResponse = await fetch(pollUrl, {
                    method: 'POST',
                    headers: pollHeaders,
                    body: JSON.stringify({ operationName: videoJobName }),
                });

                if (!pollResponse.ok) {
                    const errorText = await pollResponse.text();
                    console.warn(`${apiName} video job status error: ${pollResponse.status} ${pollResponse.statusText}`, errorText);
                    return response.status(500).send('Video job status request failed');
                }

                /** @type {any} */
                const pollData = await pollResponse.json();
                const jobDone = pollData?.done;
                console.debug(`${apiName} video job status attempt ${attempt + 1}: ${jobDone ? 'done' : 'running'}`);

                if (jobDone) {
                    const videoData = pollData?.response?.videos?.[0]?.bytesBase64Encoded;
                    if (!videoData) {
                        const pollDataLog = util.inspect(pollData, { depth: 5, colors: true, maxStringLength: 500 });
                        console.warn(`${apiName} video generation error: No video data found in response`, pollDataLog);
                        return response.status(500).send('No video data found in response');
                    }

                    return response.send({ video: videoData });
                }
            } else {
                const pollUrl = urlJoin(baseUrl, videoJobName);
                const pollResponse = await fetch(pollUrl, {
                    method: 'GET',
                    headers: headers,
                });

                if (!pollResponse.ok) {
                    const errorText = await pollResponse.text();
                    console.warn(`${apiName} video job status error: ${pollResponse.status} ${pollResponse.statusText}`, errorText);
                    return response.status(500).send('Video job status request failed');
                }

                /** @type {any} */
                const pollData = await pollResponse.json();
                const jobDone = pollData?.done;
                console.debug(`${apiName} video job status attempt ${attempt + 1}: ${jobDone ? 'done' : 'running'}`);

                if (jobDone) {
                    const videoUri = pollData?.response?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri;
                    console.debug(`${apiName} video URI:`, videoUri);

                    if (!videoUri) {
                        const pollDataLog = util.inspect(pollData, { depth: 5, colors: true, maxStringLength: 500 });
                        console.warn(`${apiName} video generation error: No video URI found in response`, pollDataLog);
                        return response.status(500).send('No video URI found in response');
                    }

                    const videoResponse = await fetch(videoUri, {
                        method: 'GET',
                        headers: headers,
                    });

                    if (!videoResponse.ok) {
                        console.warn(`${apiName} video fetch error: ${videoResponse.status} ${videoResponse.statusText}`);
                        return response.status(500).send('Video fetch request failed');
                    }

                    const videoData = await videoResponse.arrayBuffer();
                    const videoBase64 = Buffer.from(videoData).toString('base64');

                    return response.send({ video: videoBase64 });
                }
            }
        }

        console.warn(`${apiName} video generation error: Job timed out after multiple attempts`);
        return response.status(500).send('Video generation timed out');
    } catch (error) {
        console.error('Google Video generation failed:', error);
        return response.sendStatus(500);
    }
});

// Gemini TTS (Unofficial API) endpoints
router.post('/gemini-tts/extract-token', async (request, response) => {
    try {
        const geminiResponse = await fetch('https://gemini.google.com', {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            },
        });
        
        if (!geminiResponse.ok) {
            throw new Error(`HTTP ${geminiResponse.status}: ${geminiResponse.statusText}`);
        }
        
        const text = await geminiResponse.text();
        
        // Try multiple regex patterns to find the token
        // Token is usually in a script tag or as a variable
        let match = null;
        const patterns = [
            /SNlM0e":"([^"]+)"/,                    // Standard pattern with quotes
            /SNlM0e['"]?\s*[:=]\s*['"]([^'"]+)['"]/, // Variable assignment
            /"SNlM0e"\s*:\s*"([^"]+)"/,            // JSON format
            /SNlM0e\s*=\s*["']([^"']+)["']/,       // Assignment format
            /SNlM0e['"]?\s*:\s*['"]([^'"]+)['"]/,  // Colon separator
            /SNlM0e[^"']*["']([^"']+)["']/,        // Flexible pattern
        ];
        
        for (const pattern of patterns) {
            // Use global flag to search entire response
            const regex = new RegExp(pattern.source, 'g');
            let result;
            while ((result = regex.exec(text)) !== null) {
                if (result[1] && result[1].length > 10 && result[1].length < 200) {
                    match = result;
                    break;
                }
            }
            if (match) break;
        }
        
        // Also try searching in script tags specifically
        if (!match) {
            const scriptMatches = text.match(/<script[^>]*>([\s\S]*?)<\/script>/gi);
            if (scriptMatches) {
                for (const script of scriptMatches) {
                    const patterns = [
                        /SNlM0e["']?\s*[:=]\s*["']([^"']+)["']/,
                        /SNlM0e\s*=\s*["']([^"']+)["']/,
                    ];
                    for (const pattern of patterns) {
                        const result = pattern.exec(script);
                        if (result && result[1] && result[1].length > 10 && result[1].length < 200) {
                            match = result;
                            break;
                        }
                    }
                    if (match) break;
                }
            }
        }
        
        if (match && match[1]) {
            const token = match[1].trim();
            if (token.length > 10 && token.length < 200) {
                console.debug('Gemini TTS: Successfully extracted token (length:', token.length, ')');
                return response.json({ token: token });
            }
        }
        
        // Log debugging info
        console.error('Gemini TTS: Token not found in response.');
        console.error('Response length:', text.length);
        
        // Check if response contains any mention of SNlM0e
        if (text.includes('SNlM0e')) {
            console.error('Response contains "SNlM0e" but regex did not match.');
            // Find all occurrences
            const allMatches = [];
            let searchIndex = 0;
            while ((searchIndex = text.indexOf('SNlM0e', searchIndex)) !== -1) {
                const context = text.substring(Math.max(0, searchIndex - 50), Math.min(text.length, searchIndex + 150));
                allMatches.push(context);
                searchIndex += 6;
                if (allMatches.length > 5) break; // Limit to 5 matches
            }
            console.error('Context around SNlM0e occurrences:', allMatches);
        } else {
            console.error('Response does not contain "SNlM0e" at all.');
            // Try to find token-like patterns in JavaScript code
            // Look for patterns like: var token = "...", token: "...", etc.
            const tokenPatterns = [
                /(?:token|at|authToken|apiToken|sessionToken)\s*[:=]\s*["']([^"']{20,200})["']/gi,
                /["']([A-Za-z0-9_-]{20,200})["']\s*[:=]\s*(?:token|at|auth)/gi,
            ];
            
            for (const pattern of tokenPatterns) {
                const results = [];
                let result;
                while ((result = pattern.exec(text)) !== null && results.length < 10) {
                    if (result[1] && result[1].length > 20) {
                        results.push(result[1]);
                    }
                }
                if (results.length > 0) {
                    console.error('Found potential tokens:', results.slice(0, 3));
                }
            }
            
            // Check for similar patterns and try to extract them
            const similarPatterns = ['SNl', 'SN1', 'SNI'];
            for (const pattern of similarPatterns) {
                if (text.includes(pattern)) {
                    console.error(`Response contains "${pattern}" - trying to extract...`);
                    // Try to find token-like strings near these patterns
                    const contextPattern = new RegExp(`${pattern}[^"']{0,50}["']([^"']{20,200})["']`, 'gi');
                    const contextMatch = contextPattern.exec(text);
                    if (contextMatch && contextMatch[1] && contextMatch[1].length > 20) {
                        console.error(`Found potential token near "${pattern}":`, contextMatch[1].substring(0, 50) + '...');
                        // Return this as potential token
                        return response.json({ token: contextMatch[1] });
                    }
                }
            }
            
            // Also check for common token patterns
            const commonTokenPatterns = ['token', 'at=', 'auth', 'session'];
            for (const pattern of commonTokenPatterns) {
                if (text.includes(pattern)) {
                    console.error(`Response contains "${pattern}" - might be related.`);
                }
            }
        }
        
        // Since token extraction failed, try to proceed without token or use empty token
        // Some APIs might work without token or with empty token
        console.warn('Gemini TTS: Proceeding without token - API might work without it or token might not be required anymore.');
        return response.json({ token: '' });
    } catch (error) {
        console.error('Gemini TTS token extraction failed:', error);
        return response.status(500).json({ error: error.message });
    }
});

// Rate limiting: track last request time to avoid hitting limits
let lastGeminiTtsRequest = 0;
const MIN_REQUEST_INTERVAL = 1000; // Minimum 1 second between requests

router.post('/gemini-tts/generate', async (request, response) => {
    try {
        const { text, voiceId, token } = request.body;
        
        // Rate limiting: add delay between requests to avoid hitting API limits
        const now = Date.now();
        const timeSinceLastRequest = now - lastGeminiTtsRequest;
        if (timeSinceLastRequest < MIN_REQUEST_INTERVAL) {
            const delayNeeded = MIN_REQUEST_INTERVAL - timeSinceLastRequest;
            await delay(delayNeeded);
        }
        lastGeminiTtsRequest = Date.now();

        if (!text || !voiceId) {
            return response.status(400).json({ error: 'Missing required parameters: text and voiceId are required' });
        }
        
        // Token might be optional now, but we'll try with empty string if not provided
        const authToken = token || '';

        // Voice list mapping
        const voiceList = {
            'en-AU': 'en', 'en-GB': 'en', 'en-US': 'en', 'af-ZA': 'af', 'sq': 'sq',
            'ar-AE': 'ar', 'hy': 'hy', 'bn-BD': 'bn', 'bn-IN': 'bn', 'bs': 'bs',
            'my': 'my', 'ca-ES': 'ca', 'cmn-Hant-TW': 'cmn', 'hr-HR': 'hr',
            'cs-CZ': 'cs', 'da-DK': 'da', 'nl-NL': 'nl', 'eo': 'eo', 'et': 'et',
            'fil-PH': 'fil', 'fi-FI': 'fi', 'fr-FR': 'fr', 'fr-CA': 'fr',
            'de-DE': 'de', 'el-GR': 'el', 'gu': 'gu', 'hi-IN': 'hi', 'hu-HU': 'hu',
            'is-IS': 'is', 'id-ID': 'id', 'it-IT': 'it', 'ja-JP': 'ja', 'kn': 'kn',
            'km': 'km', 'ko-KR': 'ko', 'la': 'la', 'lv': 'lv', 'mk': 'mk',
            'ml': 'ml', 'mr': 'mr', 'ne': 'ne', 'nb-NO': 'nb', 'pl-PL': 'pl',
            'pt-BR': 'pt', 'ro-RO': 'ro', 'ru-RU': 'ru', 'sr-RS': 'sr', 'si': 'si',
            'sk-SK': 'sk', 'es-MX': 'es', 'es-ES': 'es', 'sw': 'sw', 'sv-SE': 'sv',
            'ta': 'ta', 'te': 'te', 'th-TH': 'th', 'tr-TR': 'tr', 'uk-UA': 'uk',
            'ur': 'ur', 'cy': 'cy', 'vi-VN': 'vi',
        };

        const lang = voiceList[voiceId] || 'vi';
        const reqId = 100000 + parseInt(Array.from({ length: 4 }, () => Math.floor(Math.random() * 10)).join(''), 10);
        const bardWebServer = 'boq_assistant-bard-web-server_20241014.09_p1';

        // Build payload
        const content = [null, text, lang, null, 2];
        const data = ['XqA3Ic', JSON.stringify(content), null, 'generic'];
        const payloadData = JSON.stringify([[data]]);

        // Build URL
        const url = new URL('https://gemini.google.com/_/BardChatUi/data/batchexecute');
        url.searchParams.append('rpcids', 'XqA3Ic');
        url.searchParams.append('bl', bardWebServer);
        url.searchParams.append('hl', lang);
        url.searchParams.append('_reqid', reqId.toString());
        url.searchParams.append('rt', 'c');

        // Make request with retry logic for rate limiting
        let ttsResponse;
        let lastError;
        const maxRetries = 3;
        const baseDelay = 2000; // 2 seconds
        
        for (let attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                ttsResponse = await fetch(url.toString(), {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    },
                    body: `f.req=${encodeURIComponent(payloadData)}&at=${authToken}`,
                });

                // Check for rate limit (429) or server errors (5xx)
                if (ttsResponse.status === 429 || (ttsResponse.status >= 500 && ttsResponse.status < 600)) {
                    if (attempt < maxRetries) {
                        const delayMs = baseDelay * Math.pow(2, attempt); // Exponential backoff
                        console.warn(`Gemini TTS: Rate limited or server error (${ttsResponse.status}). Retrying in ${delayMs}ms... (attempt ${attempt + 1}/${maxRetries + 1})`);
                        await delay(delayMs);
                        continue;
                    }
                }
                
                if (!ttsResponse.ok) {
                    let errorMessage = `HTTP ${ttsResponse.status}: ${ttsResponse.statusText}`;
                    
                    // Handle rate limiting specifically
                    if (ttsResponse.status === 429) {
                        errorMessage = 'Rate limit exceeded. Please wait a few minutes before trying again.';
                    } else if (ttsResponse.status >= 500) {
                        errorMessage = 'Gemini TTS service is temporarily unavailable. Please try again later.';
                    }
                    
                    // Try to get error details from response
                    try {
                        const errorText = await ttsResponse.text();
                        if (errorText) {
                            console.error('Gemini TTS error response:', errorText.substring(0, 500));
                        }
                    } catch (e) {
                        // Ignore parse errors
                    }
                    
                    throw new Error(errorMessage);
                }
                
                // Success, break out of retry loop
                break;
            } catch (error) {
                lastError = error;
                if (attempt < maxRetries && !error.message.includes('Rate limit')) {
                    const delayMs = baseDelay * Math.pow(2, attempt);
                    console.warn(`Gemini TTS: Request failed. Retrying in ${delayMs}ms... (attempt ${attempt + 1}/${maxRetries + 1})`);
                    await delay(delayMs);
                } else {
                    // If rate limited, don't retry - throw immediately
                    throw error;
                }
            }
        }

        if (!ttsResponse || !ttsResponse.ok) {
            const errorMsg = lastError ? lastError.message : `HTTP ${ttsResponse?.status}: ${ttsResponse?.statusText}`;
            throw new Error(`Gemini TTS request failed after ${maxRetries + 1} attempts: ${errorMsg}`);
        }

        const responseText = await ttsResponse.text();
        const match = /(\[\["wrb.fr".*?"generic"]])/.exec(responseText);

        if (!match) {
            throw new Error('Failed to parse response');
        }

        const jsonArray = JSON.parse(match[1]);
        const contentArray = JSON.parse(jsonArray[0][2]);

        if (!contentArray || !contentArray[0]) {
            throw new Error('Invalid response format');
        }

        // Return base64 audio data
        return response.json({ audio: contentArray[0] });
    } catch (error) {
        console.error('Gemini TTS generation failed:', error);
        return response.status(500).json({ error: error.message });
    }
});
