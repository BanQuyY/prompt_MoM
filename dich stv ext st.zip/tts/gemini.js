import { getRequestHeaders } from '../../../script.js';
import { getPreviewString, saveTtsProviderSettings } from './index.js';

export { GeminiTtsProvider };

class GeminiTtsProvider {
    settings;
    voices = [];
    separator = ' . ';
    audioElement = document.createElement('audio');
    SNlM0e = null;

    defaultSettings = {
        voiceMap: {},
    };

    get settingsHtml() {
        return `
        <div class="gemini_tts_hints">
            <div>Use Gemini TTS engine (unofficial API).</div>
            <small>Note: This uses an unofficial API endpoint. No API key required.</small>
        </div>`;
    }

    async loadSettings(settings) {
        if (Object.keys(settings).length === 0) {
            console.info('Using default Gemini TTS Provider settings');
        }

        this.settings = { ...this.defaultSettings, ...settings };

        try {
            await this.checkReady();
            console.debug('GeminiTTS: Settings loaded');
        } catch (err) {
            console.warn('GeminiTTS: Settings loaded, but not ready.', err.message);
        }
    }

    onSettingsChange() {
        saveTtsProviderSettings();
    }

    async checkReady() {
        await this.fetchTtsVoiceObjects();
    }

    async onRefreshClick() {
        // Force refresh token
        try {
            await this.refreshToken();
            toastr.success('Token refreshed successfully', 'Gemini TTS', { timeOut: 3000 });
        } catch (error) {
            toastr.error(`Failed to refresh token: ${error.message}`, 'Gemini TTS', { timeOut: 5000 });
        }
        await this.checkReady();
    }

    //#################//
    //  TTS Interfaces //
    //#################//

    /**
     * Get a voice from the TTS provider.
     * @param {string} voiceName Voice name to get
     * @returns {Promise<Object>} Voice object
     */
    async getVoice(voiceName) {
        if (this.voices.length === 0) {
            this.voices = await this.fetchTtsVoiceObjects();
        }

        const match = this.voices.find(voice => voice.name === voiceName || voice.voice_id === voiceName);

        if (!match) {
            throw `TTS Voice name ${voiceName} not found`;
        }
        return match;
    }

    /**
     * Generate TTS audio for the given text using the specified voice.
     * @param {string} text Text to convert to speech
     * @param {string} voiceId Voice ID to use
     * @returns {Promise<string>} Data URL string containing audio data
     */
    async generateTts(text, voiceId) {
        const base64Audio = await this.fetchTtsGeneration(text, voiceId);
        // Return as data URL string
        if (base64Audio.startsWith('data:')) {
            return base64Audio;
        }
        return `data:audio/mpeg;base64,${base64Audio}`;
    }

    async fetchTtsVoiceObjects() {
        // Return the voice list from the plugin
        const voices = [
            { voice_id: 'en-AU', name: 'English (Australia)', lang: 'en' },
            { voice_id: 'en-GB', name: 'English (UK)', lang: 'en' },
            { voice_id: 'en-US', name: 'English (US)', lang: 'en' },
            { voice_id: 'af-ZA', name: 'Afrikaans', lang: 'af' },
            { voice_id: 'sq', name: 'Albanian', lang: 'sq' },
            { voice_id: 'ar-AE', name: 'Arabic (UAE)', lang: 'ar' },
            { voice_id: 'hy', name: 'Armenian', lang: 'hy' },
            { voice_id: 'bn-BD', name: 'Bengali (Bangladesh)', lang: 'bn' },
            { voice_id: 'bn-IN', name: 'Bengali (India)', lang: 'bn' },
            { voice_id: 'bs', name: 'Bosnian', lang: 'bs' },
            { voice_id: 'my', name: 'Burmese', lang: 'my' },
            { voice_id: 'ca-ES', name: 'Catalan', lang: 'ca' },
            { voice_id: 'cmn-Hant-TW', name: 'Chinese (Traditional, Taiwan)', lang: 'cmn' },
            { voice_id: 'hr-HR', name: 'Croatian', lang: 'hr' },
            { voice_id: 'cs-CZ', name: 'Czech', lang: 'cs' },
            { voice_id: 'da-DK', name: 'Danish', lang: 'da' },
            { voice_id: 'nl-NL', name: 'Dutch', lang: 'nl' },
            { voice_id: 'eo', name: 'Esperanto', lang: 'eo' },
            { voice_id: 'et', name: 'Estonian', lang: 'et' },
            { voice_id: 'fil-PH', name: 'Filipino', lang: 'fil' },
            { voice_id: 'fi-FI', name: 'Finnish', lang: 'fi' },
            { voice_id: 'fr-FR', name: 'French (France)', lang: 'fr' },
            { voice_id: 'fr-CA', name: 'French (Canada)', lang: 'fr' },
            { voice_id: 'de-DE', name: 'German', lang: 'de' },
            { voice_id: 'el-GR', name: 'Greek', lang: 'el' },
            { voice_id: 'gu', name: 'Gujarati', lang: 'gu' },
            { voice_id: 'hi-IN', name: 'Hindi', lang: 'hi' },
            { voice_id: 'hu-HU', name: 'Hungarian', lang: 'hu' },
            { voice_id: 'is-IS', name: 'Icelandic', lang: 'is' },
            { voice_id: 'id-ID', name: 'Indonesian', lang: 'id' },
            { voice_id: 'it-IT', name: 'Italian', lang: 'it' },
            { voice_id: 'ja-JP', name: 'Japanese', lang: 'ja' },
            { voice_id: 'kn', name: 'Kannada', lang: 'kn' },
            { voice_id: 'km', name: 'Khmer', lang: 'km' },
            { voice_id: 'ko-KR', name: 'Korean', lang: 'ko' },
            { voice_id: 'la', name: 'Latin', lang: 'la' },
            { voice_id: 'lv', name: 'Latvian', lang: 'lv' },
            { voice_id: 'mk', name: 'Macedonian', lang: 'mk' },
            { voice_id: 'ml', name: 'Malayalam', lang: 'ml' },
            { voice_id: 'mr', name: 'Marathi', lang: 'mr' },
            { voice_id: 'ne', name: 'Nepali', lang: 'ne' },
            { voice_id: 'nb-NO', name: 'Norwegian', lang: 'nb' },
            { voice_id: 'pl-PL', name: 'Polish', lang: 'pl' },
            { voice_id: 'pt-BR', name: 'Portuguese (Brazil)', lang: 'pt' },
            { voice_id: 'ro-RO', name: 'Romanian', lang: 'ro' },
            { voice_id: 'ru-RU', name: 'Russian', lang: 'ru' },
            { voice_id: 'sr-RS', name: 'Serbian', lang: 'sr' },
            { voice_id: 'si', name: 'Sinhala', lang: 'si' },
            { voice_id: 'sk-SK', name: 'Slovak', lang: 'sk' },
            { voice_id: 'es-MX', name: 'Spanish (Mexico)', lang: 'es' },
            { voice_id: 'es-ES', name: 'Spanish (Spain)', lang: 'es' },
            { voice_id: 'sw', name: 'Swahili', lang: 'sw' },
            { voice_id: 'sv-SE', name: 'Swedish', lang: 'sv' },
            { voice_id: 'ta', name: 'Tamil', lang: 'ta' },
            { voice_id: 'te', name: 'Telugu', lang: 'te' },
            { voice_id: 'th-TH', name: 'Thai', lang: 'th' },
            { voice_id: 'tr-TR', name: 'Turkish', lang: 'tr' },
            { voice_id: 'uk-UA', name: 'Ukrainian', lang: 'uk' },
            { voice_id: 'ur', name: 'Urdu', lang: 'ur' },
            { voice_id: 'cy', name: 'Welsh', lang: 'cy' },
            { voice_id: 'vi-VN', name: 'Vietnamese', lang: 'vi' },
        ];

        this.voices = voices;
        return voices;
    }

    async previewTtsVoice(id) {
        this.audioElement.pause();
        this.audioElement.currentTime = 0;

        try {
            const voice = await this.getVoice(id);
            const text = getPreviewString(voice.lang || 'en-US');

            const base64Audio = await this.fetchTtsGeneration(text, id);

            if (!base64Audio) {
                toastr.error('Could not generate preview');
                return;
            }

            // Convert base64 to blob
            const audioData = base64Audio.startsWith('data:') 
                ? base64Audio 
                : `data:audio/mpeg;base64,${base64Audio}`;
            
            const response = await fetch(audioData);
            const audioBlob = await response.blob();
            const url = URL.createObjectURL(audioBlob);
            this.audioElement.src = url;
            this.audioElement.play();
            this.audioElement.onended = () => URL.revokeObjectURL(url);

        } catch (error) {
            console.error('TTS Preview Error:', error);
            toastr.error(`Could not generate preview: ${error.message}`);
        }
    }

    /**
     * Force refresh the token by fetching a new one from the server
     */
    async refreshToken() {
        console.info('Gemini TTS: Refreshing token...');
        this.SNlM0e = null;
        localStorage.removeItem('GeminiTTS_SNlM0e');
        
        try {
            const tokenResponse = await fetch('/api/google/gemini-tts/extract-token', {
                method: 'POST',
                headers: getRequestHeaders(),
                body: JSON.stringify({}),
            });

            if (!tokenResponse.ok) {
                let errorMessage = `HTTP ${tokenResponse.status}: ${tokenResponse.statusText}`;
                try {
                    const errorData = await tokenResponse.json();
                    errorMessage = errorData.error || errorMessage;
                } catch (e) {
                    const errorText = await tokenResponse.text();
                    console.error('Gemini TTS token extraction error response:', errorText);
                }
                throw new Error(errorMessage);
            }

            const tokenData = await tokenResponse.json();
            this.SNlM0e = tokenData.token;
            
            if (!this.SNlM0e) {
                throw new Error('Token was returned but is empty');
            }
            
            // Cache the token with timestamp
            localStorage.setItem('GeminiTTS_SNlM0e', this.SNlM0e);
            localStorage.setItem('GeminiTTS_SNlM0e_timestamp', Date.now().toString());
            console.info('Gemini TTS: Token refreshed successfully');
            return this.SNlM0e;
        } catch (error) {
            console.error('Gemini TTS: Failed to refresh token:', error);
            throw error;
        }
    }

    /**
     * Get token, refreshing if needed
     */
    async getToken(forceRefresh = false) {
        // Check if token is expired (older than 1 hour)
        const tokenTimestamp = localStorage.getItem('GeminiTTS_SNlM0e_timestamp');
        const tokenAge = tokenTimestamp ? Date.now() - parseInt(tokenTimestamp) : Infinity;
        const TOKEN_TTL = 60 * 60 * 1000; // 1 hour
        
        if (forceRefresh || !this.SNlM0e || tokenAge > TOKEN_TTL) {
            await this.refreshToken();
        } else if (!this.SNlM0e) {
            // Try to get from localStorage
            const cachedToken = localStorage.getItem('GeminiTTS_SNlM0e');
            if (cachedToken) {
                this.SNlM0e = cachedToken;
            } else {
                await this.refreshToken();
            }
        }
        
        return this.SNlM0e;
    }

    async fetchTtsGeneration(text, voiceId) {
        console.info(`Generating Gemini TTS for voice_id ${voiceId}`);

        try {
            // Get token (will auto-refresh if needed)
            await this.getToken();

            // Use server-side endpoint to generate TTS
            const response = await fetch('/api/google/gemini-tts/generate', {
                method: 'POST',
                headers: getRequestHeaders(),
                body: JSON.stringify({
                    text: text,
                    voiceId: voiceId,
                    token: this.SNlM0e,
                }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
            }

            const responseData = await response.json();
            
            if (!responseData.audio) {
                throw new Error('Invalid response format: audio data not found');
            }

            // Return base64 audio data
            return responseData.audio;

        } catch (error) {
            console.error('Gemini TTS generation failed:', error);
            
            // Check if it's a rate limit error
            if (error.message && (error.message.includes('Rate limit') || error.message.includes('429'))) {
                // Try refreshing token when rate limited - might help
                console.info('Gemini TTS: Rate limited, attempting to refresh token...');
                try {
                    await this.refreshToken();
                    toastr.info('Token refreshed. You can try again now.', 'Gemini TTS', { timeOut: 5000 });
                } catch (refreshError) {
                    console.warn('Failed to refresh token after rate limit:', refreshError);
                    toastr.warning('Gemini TTS rate limit reached. Please wait a few minutes before trying again.', 'Rate Limit', { timeOut: 10000 });
                }
            } else if (error.message && error.message.includes('401') || error.message.includes('403')) {
                // Authentication error - refresh token
                console.info('Gemini TTS: Authentication error, refreshing token...');
                try {
                    await this.refreshToken();
                    toastr.info('Token refreshed due to authentication error. Please try again.', 'Gemini TTS', { timeOut: 5000 });
                } catch (refreshError) {
                    console.error('Failed to refresh token after auth error:', refreshError);
                }
            } else {
                // For other errors, don't clear token immediately
                // Token might still be valid
            }
            
            throw error;
        }
    }


    /**
     * Process text before TTS generation
     * @param {string} text Input text
     * @returns {Promise<string>} Processed text
     */
    async processText(text) {
        return text;
    }
}

