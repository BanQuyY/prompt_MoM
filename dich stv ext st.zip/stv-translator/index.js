
import {
    eventSource,
    event_types,
    getRequestHeaders,
    saveSettingsDebounced,
} from '../../../../script.js';
import { extension_settings, renderExtensionTemplateAsync } from '../../../../scripts/extensions.js';
import { SlashCommand } from '../../../../scripts/slash-commands/SlashCommand.js';
import { ARGUMENT_TYPE, SlashCommandArgument } from '../../../../scripts/slash-commands/SlashCommandArgument.js';
import { SlashCommandParser } from '../../../../scripts/slash-commands/SlashCommandParser.js';

const extensionName = 'stv-translator';

const defaultSettings = {
    enabled: true,
    stvServer: 'comic.sangtacvietcdn.xyz/tsm.php?cdn=',
    namedata: '', // Dùng cho OUTPUT translation (Zh→Vi)
    inputDictionary: '', // Dùng cho INPUT auto-convert (Vi→Zh)
    excludes: '',
    render: true,
    debug: false,
    maxRetries: 2,
    translateOnlyReasoning: false,
    cacheEnabled: true,
    geminiApiKey: '', // User must provide their own API key
    geminiModel: 'gemini-2.0-flash-exp',
    geminiProxyEndpoint: '', // Optional proxy endpoint for Gemini API
    enableInputTranslation: true,
};

// Translation cache
const translationCache = new Map();
const CACHE_MAX_SIZE = 1000;
const BATCH_SIZE = 100;
const DEBOUNCE_TIME = 500;
const LOCK_TIMEOUT = 5000;

// Chinese character regex
const chineseRegex = /[\u3400-\u9FBF]/;

// Lock to prevent parallel translations
let realtimeTranslateLock = false;
let lockTimeoutHandle = null;
let namedatacache = null;
let inputDictionaryCache = null;

// Track elements that already have hover listeners to prevent memory leaks
const elementsWithHoverListeners = new WeakSet();

// MutationObserver for auto-translation
let mutationObserver = null;

// Periodic scanner for catching dynamic content
let periodicScanner = null;

/**
 * Debug logger
 */
function debugLog(...args) {
    if (extension_settings[extensionName]?.debug) {
        console.log('[STV Translator]', ...args);
    }
}

/**
 * Get cached translation
 */
function getCachedTranslation(text) {
    return translationCache.get(text);
}

/**
 * Set cached translation
 */
function setCachedTranslation(text, translation) {
    if (translationCache.size >= CACHE_MAX_SIZE) {
        const firstKey = translationCache.keys().next().value;
        translationCache.delete(firstKey);
    }
    translationCache.set(text, translation);
}

/**
 * Replace Chinese names with Vietnamese translations (OUTPUT)
 */
function replaceName(text) {
    let result = text;
    const namedata = extension_settings[extensionName]?.namedata || '';
    
    if (!namedata) return result;
    
    if (namedatacache && namedatacache.namedata === namedata) {
        // Use cached regex patterns only if namedata hasn't changed
        for (let i = 0; i < namedatacache.patterns.length; i++) {
            result = result.replace(namedatacache.patterns[i][0], namedatacache.patterns[i][1]);
        }
        return result;
    }
    
    // Build new cache
    namedatacache = {
        namedata: namedata,
        patterns: []
    };
    const lines = namedata.split('\n');
    
    // Create array of name pairs with length info
    const namePairs = [];
    for (const line of lines) {
        const parts = line.trim().split('=');
        if (parts[0] && parts[1]) {
            namePairs.push({
                chinese: parts[0],
                translation: parts[1],
                length: parts[0].length,
            });
        }
    }
    
    // Sort by length (longest first)
    namePairs.sort((a, b) => b.length - a.length);
    
    // Replace names
    const chineseCharPattern = '[\\u3400-\\u9FBF\\u3040-\\u309F\\u30A0-\\u30FF\\uAC00-\\uD7AF]';
    for (const pair of namePairs) {
        // Pattern with lookahead: if followed by CJK character, add space
        const regex1 = new RegExp(pair.chinese + '(?=' + chineseCharPattern + ')', 'g');
        namedatacache.patterns.push([regex1, pair.translation + ' ']);
        result = result.replace(regex1, pair.translation + ' ');
        
        // Normal pattern
        const regex2 = new RegExp(pair.chinese, 'g');
        namedatacache.patterns.push([regex2, pair.translation]);
        result = result.replace(regex2, pair.translation);
    }
    
    return result;
}

/**
 * Replace Vietnamese names with Chinese names (INPUT auto-convert)
 * CHỈ replace nếu có trong inputDictionary
 * Example: "Mike" -> "迈克" (nếu inputDictionary có "Mike=迈克")
 */
function reverseReplaceName(text) {
    let result = text;
    const inputDictionary = extension_settings[extensionName]?.inputDictionary || '';
    
    if (!inputDictionary) return result;
    
    const lines = inputDictionary.split('\n');
    const namePairs = [];
    
    for (const line of lines) {
        const parts = line.trim().split('=');
        if (parts[0] && parts[1]) {
            namePairs.push({
                chinese: parts[0].trim(),
                vietnamese: parts[1].trim(),
                length: parts[1].trim().length,
            });
        }
    }
    
    // Sort by Vietnamese name length (longest first) to avoid partial matches
    namePairs.sort((a, b) => b.length - a.length);
    
    // Replace Vietnamese names with Chinese names
    for (const pair of namePairs) {
        // Escape special regex characters
        const escapedVietnamese = pair.vietnamese.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        
        // Use lookahead/lookbehind for better matching with Vietnamese text
        // Match the name when it's surrounded by spaces, punctuation, or at start/end
        // This works better than \b for Vietnamese with diacritics
        const regex = new RegExp(
            '(^|[\\s.,!?;:(){}\\[\\]"\'-])(' + escapedVietnamese + ')(?=[\\s.,!?;:(){}\\[\\]"\'-]|$)',
            'gi'
        );
        result = result.replace(regex, '$1' + pair.chinese);
    }
    
    return result;
}

/**
 * Translate text using STV/VP/DichNhanh API (Direct API calls from browser)
 */
async function translateText(text, retryCount = 0) {
    try {
        if (!text || text.trim() === '') {
            return '';
        }
        
        // Check cache first
        if (extension_settings[extensionName]?.cacheEnabled) {
            const cached = getCachedTranslation(text);
            if (cached) {
                debugLog('Cache hit:', text.substring(0, 50));
                return cached;
            }
        }
        
        const stvServer = extension_settings[extensionName]?.stvServer || 'comic.sangtacvietcdn.xyz/tsm.php?cdn=';
        const namedata = extension_settings[extensionName]?.namedata || '';
        
        debugLog('📤 Translating:', {
            textLength: text.length,
            textPreview: text.substring(0, 100) + (text.length > 100 ? '...' : ''),
            server: stvServer,
            hasNamedata: !!namedata,
        });
        
        // Detect server type
        const isDichNhanhServer = stvServer.includes('dichnhanh.com');
        const isVpServer = stvServer.includes('localhost') ||
                          stvServer.includes('127.0.0.1') ||
                          stvServer.includes(':500') ||
                          stvServer.includes('hf.space') ||
                          stvServer.match(/:\d{4,5}$/) ||
                          stvServer.includes('/translate');
        
        let translated;
        
        if (isDichNhanhServer) {
            translated = await translateWithDichNhanh(text, namedata);
        } else if (isVpServer) {
            translated = await translateWithVpServer(text, stvServer, namedata);
        } else {
            translated = await translateWithStvApi(text, stvServer, namedata);
        }
        
        // Cache the result
        if (extension_settings[extensionName]?.cacheEnabled) {
            setCachedTranslation(text, translated);
        }
        
        return translated;
    } catch (error) {
        debugLog('Translation error:', error);
        
        // Retry logic
        const maxRetries = extension_settings[extensionName]?.maxRetries || 2;
        if (retryCount < maxRetries) {
            debugLog(`Retrying (${retryCount + 1}/${maxRetries})...`);
            await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1)));
            return await translateText(text, retryCount + 1);
        }
        
        console.error('STV Translator: Failed to translate after retries', error);
        return text; // Return original text on failure
    }
}

/**
 * Translate using DichNhanh API
 */
async function translateWithDichNhanh(text, namedata) {
    // Apply name replacements BEFORE translation
    let processedText = text;
    if (namedata) {
        processedText = replaceName(processedText);
    }
    
    const apiUrl = 'https://api.dichnhanh.com/';
    const formData = new URLSearchParams();
    formData.append('type', 'Ancient');
    formData.append('enable_analyze', '1');
    formData.append('enable_fanfic', '0');
    formData.append('mode', 'vi');
    formData.append('text', processedText);
    formData.append('remove', '');
    
    const apiResponse = await fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Origin': 'https://dichnhanh.com',
            'Referer': 'https://dichnhanh.com/',
        },
        body: formData.toString(),
    });
    
    if (!apiResponse.ok) {
        throw new Error(`DichNhanh API error: ${apiResponse.status} ${apiResponse.statusText}`);
    }
    
    const result = await apiResponse.json();
    
    if (result && result.success === true && result.data && result.data.content) {
        const translatedText = String(result.data.content);
        if (!translatedText || translatedText.trim() === '') {
            return text;
        }
        return translatedText;
    }
    
    throw new Error(result.message || 'Invalid response from DichNhanh API');
}

/**
 * Translate using VP Server API
 * VP Server handles name replacements using its own Names.txt file
 */
async function translateWithVpServer(text, server, namedata) {
    // VP Server handles name replacements internally
    // Build API URL
    let apiUrl = server;
    
    // Add protocol if missing
    if (!apiUrl.startsWith('http://') && !apiUrl.startsWith('https://')) {
        const protocol = apiUrl.includes('hf.space') ? 'https://' : 'http://';
        apiUrl = protocol + apiUrl;
    }
    
    // Remove trailing slash
    apiUrl = apiUrl.replace(/\/$/, '');
    
    // Add /translate2 endpoint if not present
    if (!apiUrl.includes('/translate')) {
        apiUrl = `${apiUrl}/translate2`;
    } else if (apiUrl.endsWith('/translate')) {
        apiUrl = apiUrl.replace(/\/translate$/, '/translate2');
    }
    
    debugLog('[VP Server] Calling:', apiUrl);
    
    // Prepare request body in Azure format
    const requestBody = [{ Text: text }];
    
    const apiResponse = await fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
    });
    
    if (!apiResponse.ok) {
        throw new Error(`VP Server error: ${apiResponse.status} ${apiResponse.statusText}`);
    }
    
    const result = await apiResponse.json();
    
    // Extract translated text from Azure-like response format
    if (result && result[0] && result[0].translations && result[0].translations[0]) {
        return result[0].translations[0].text;
    }
    
    throw new Error('Invalid response format from VP server');
}

/**
 * Translate using original STV API
 */
async function translateWithStvApi(text, server, namedata) {
    // Apply name replacements BEFORE translation
    let processedText = text;
    if (namedata) {
        processedText = replaceName(processedText);
    }
    
    const apiUrl = `https://${server}`;
    const formData = new URLSearchParams();
    formData.append('sajax', 'trans');
    formData.append('content', processedText);
    
    const apiResponse = await fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData.toString(),
    });
    
    if (!apiResponse.ok) {
        throw new Error(`STV API error: ${apiResponse.status} ${apiResponse.statusText}`);
    }
    
    const translatedText = await apiResponse.text();
    return translatedText;
}

/**
 * Translate text using Gemini API (Vietnamese to Simplified Chinese)
 */
async function translateWithGemini(text) {
    try {
        if (!text || text.trim() === '') {
            return '';
        }
        
        const apiKey = extension_settings[extensionName]?.geminiApiKey;
        const model = extension_settings[extensionName]?.geminiModel || 'gemini-2.0-flash-exp';
        const proxyEndpoint = (extension_settings[extensionName]?.geminiProxyEndpoint || '').trim();
        
        // Nếu dùng endpoint proxy, không bắt buộc phải nhập API key
        if (!apiKey && !proxyEndpoint) {
            throw new Error('Gemini API key chưa được cấu hình và không có proxy endpoint');
        }
        
        // Check cache first
        const cacheKey = `gemini_vi_zh:${text}`;
        if (extension_settings[extensionName]?.cacheEnabled) {
            const cached = getCachedTranslation(cacheKey);
            if (cached) {
                debugLog('Gemini cache hit:', text.substring(0, 50));
                return cached;
            }
        }
        
        const prompt = `Bạn là một chuyên gia dịch thuật. Hãy dịch văn bản sau từ Tiếng Việt sang Tiếng Trung Giản thể.

QUAN TRỌNG:
- Chỉ trả về bản dịch, không thêm giải thích
- PHẢI GIỮ NGUYÊN tất cả các placeholder dạng {{tên}}, ví dụ: {{user}}, {{char}}, {{random}}, v.v.
- KHÔNG được dịch hoặc xóa các placeholder này
- Giữ nguyên các ký tự đặc biệt, emoji, và format markdown

Văn bản cần dịch: ${text}`;
        
        // Ưu tiên gọi qua proxy nếu được cấu hình, hỗ trợ placeholder {model}
        let apiUrl;
        if (proxyEndpoint) {
            let proxied = proxyEndpoint.replace('{model}', model).replace('{{model}}', model);
            if (!proxied.startsWith('http://') && !proxied.startsWith('https://')) {
                proxied = 'https://' + proxied;
            }
            apiUrl = proxied;
        } else {
            apiUrl = `https://ducninh.io.vn/v1beta/models/${model}:generateContent?key=${apiKey}`;
        }
        
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{ text: prompt }]
                }],
                generationConfig: {
                    temperature: 0.3,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 8192,
                }
            }),
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
        }
        
        // Đọc toàn bộ body một lần để tránh lỗi "body stream already read"
        const raw = await response.text();
        let data;
        try {
            data = JSON.parse(raw);
        } catch (parseErr) {
            throw new Error(`Gemini response parse failed: ${parseErr.message}. Raw: ${raw.substring(0, 200)}...`);
        }
        
        if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
            throw new Error('Invalid response from Gemini API');
        }
        
        const translatedText = data.candidates[0].content.parts[0].text.trim();
        
        // Cache the result
        if (extension_settings[extensionName]?.cacheEnabled) {
            setCachedTranslation(cacheKey, translatedText);
        }
        
        debugLog('Gemini translation completed:', text.substring(0, 30), '->', translatedText.substring(0, 30));
        
        return translatedText;
    } catch (error) {
        console.error('STV Translator: Gemini translation error', error);
        if (typeof toastr !== 'undefined' && toastr.error) {
            toastr.error(`Lỗi dịch Gemini: ${error.message}`, 'Translation Error');
        }
        return text; // Return original text on failure
    }
}

/**
 * Translate input message from Vietnamese to Chinese using Gemini
 */
async function translateInputMessage() {
    const sendTextArea = $('#send_textarea');
    let text = sendTextArea.val().toString();
    
    if (!text || text.trim() === '') {
        if (typeof toastr !== 'undefined' && toastr.warning) {
            toastr.warning('Vui lòng nhập văn bản cần dịch');
        }
        return;
    }
    
    if (!extension_settings[extensionName]?.enableInputTranslation) {
        if (typeof toastr !== 'undefined' && toastr.info) {
            toastr.info('Chức năng dịch input chưa được bật');
        }
        return;
    }
    
    // Replace Vietnamese names with Chinese names before translation
    text = reverseReplaceName(text);
    debugLog('Text after reverse name replacement:', text);
    
    let toastId;
    if (typeof toastr !== 'undefined' && toastr.info) {
        toastId = toastr.info('Đang dịch văn bản từ Tiếng Việt sang Tiếng Trung...', 'Vui lòng đợi', { timeOut: 0 });
    }
    
    try {
        const translatedText = await translateWithGemini(text);
        sendTextArea.val(translatedText);
        sendTextArea.trigger('input'); // Trigger input event to update UI
        if (typeof toastr !== 'undefined' && toastr.clear && toastId) {
            toastr.clear(toastId);
        }
        if (typeof toastr !== 'undefined' && toastr.success) {
            toastr.success('Đã dịch thành công!');
        }
    } catch (error) {
        if (typeof toastr !== 'undefined' && toastr.clear && toastId) {
            toastr.clear(toastId);
        }
        console.error('Translation error:', error);
    }
}

/**
 * Translate batch of texts
 */
async function translateBatch(texts) {
    if (!texts || texts.length === 0) {
        return [];
    }
    
    // Use a more unique delimiter to avoid collisions
    const delimiter = '\u200B\u200C\u200D===BATCH_SEP===\u200B\u200C\u200D';
    const batchText = texts.join(delimiter);
    
    try {
        const translated = await translateText(batchText);
        const results = translated.split(delimiter);
        
        // Validate we got the expected number of results
        if (results.length !== texts.length) {
            debugLog(`Batch split mismatch: expected ${texts.length}, got ${results.length}. Falling back to individual translation.`);
            throw new Error('Batch result count mismatch');
        }
        
        return results;
    } catch (error) {
        debugLog('Batch translation error:', error);
        // Fallback: translate individually
        const results = [];
        for (const text of texts) {
            results.push(await translateText(text));
        }
        return results;
    }
}

/**
 * Process a container and collect text nodes
 */
function processContainer(container, nodesToTranslate, textsToTranslate) {
    if (!container) return;
    
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
        if (node.parentElement.tagName !== 'SCRIPT' &&
            node.parentElement.tagName !== 'STYLE' &&
            !node.parentElement.hasAttribute('data-stv-translated')) {
            if (chineseRegex.test(node.textContent)) {
                // Check cache first
                const cachedTranslation = getCachedTranslation(node.textContent);
                if (cachedTranslation) {
                    applyTranslation(node, node.textContent, cachedTranslation);
                    continue;
                }
                
                nodesToTranslate.push(node);
                textsToTranslate.push(node.textContent);
            }
        }
    }
}

/**
 * Traverse DOM and collect text nodes to translate
 * Translates content within .mes_text containers (SillyTavern messages)
 * AND also scans for dynamic content in iframes and hidden containers
 */
function collectTextNodes(doc) {
    const nodesToTranslate = [];
    const textsToTranslate = [];
    
    if (!doc) return { nodesToTranslate, textsToTranslate };
    
    // Target SillyTavern message containers
    let messageContainers;
    let allowedContainers = null; // Track which containers are allowed for translation
    
    if (extension_settings[extensionName]?.translateOnlyReasoning) {
        debugLog('[translateOnlyReasoning] Enabled - selecting last 4 messages');
        // Lấy 4 tin nhắn cuối cùng
        const allMessages = Array.from(doc.querySelectorAll('.mes .mes_text'));
        debugLog('[translateOnlyReasoning] Total messages found:', allMessages.length);
        const lastFourMessages = allMessages.slice(-4);
        debugLog('[translateOnlyReasoning] Last 4 messages:', lastFourMessages.length);
        messageContainers = lastFourMessages;
        // Create a Set of allowed containers for fast lookup
        allowedContainers = new Set(lastFourMessages);
    } else {
        debugLog('[translateOnlyReasoning] Disabled - selecting all messages');
        messageContainers = doc.querySelectorAll('.mes .mes_text');
    }
    
    // Helper function to check if an element is within allowed containers
    function isInAllowedContainer(element) {
        if (!allowedContainers) return true; // If no restriction, allow all
        
        // Walk up the DOM tree to find if element is inside an allowed container
        let current = element;
        while (current && current !== doc.body) {
            if (allowedContainers.has(current)) {
                return true;
            }
            current = current.parentElement;
        }
        return false;
    }
    
    // Process message containers if they exist
    if (messageContainers.length > 0) {
        // Convert to array if it's a NodeList
        const containersArray = Array.isArray(messageContainers) ? messageContainers : Array.from(messageContainers);
        debugLog('Processing', containersArray.length, 'message containers');
        
        containersArray.forEach(container => {
            processContainer(container, nodesToTranslate, textsToTranslate);
            
            // Process iframes inside this container (for web games in messages)
            const iframes = container.getElementsByTagName('iframe');
            for (const iframe of iframes) {
                try {
                    if (iframe.contentDocument && iframe.contentDocument.body) {
                        processContainer(iframe.contentDocument.body, nodesToTranslate, textsToTranslate);
                        
                        // ENHANCED: Also scan hidden containers in iframe
                        const hiddenContainers = iframe.contentDocument.querySelectorAll('[style*="display: none"], [style*="display:none"], .hidden, .app-data-container');
                        hiddenContainers.forEach(hiddenContainer => {
                            processContainer(hiddenContainer, nodesToTranslate, textsToTranslate);
                        });
                    }
                } catch (e) {
                    debugLog('Cannot access iframe:', e);
                }
            }
        });
    }
    
    // ENHANCED: Scan all iframes at document level for dynamic content
    // BUT only if they belong to allowed containers (when translateOnlyReasoning is enabled)
    const allIframes = doc.getElementsByTagName('iframe');
    for (const iframe of allIframes) {
        // Skip if already processed inside message containers
        let alreadyProcessed = false;
        if (messageContainers.length > 0) {
            const containersArray = Array.isArray(messageContainers) ? messageContainers : Array.from(messageContainers);
            for (const container of containersArray) {
                if (container.contains(iframe)) {
                    alreadyProcessed = true;
                    break;
                }
            }
        }
        
        if (alreadyProcessed) {
            continue;
        }
        
        // Check if this iframe is within an allowed container
        if (!isInAllowedContainer(iframe)) {
            debugLog('[translateOnlyReasoning] Skipping iframe - not in allowed containers');
            continue;
        }
        
        try {
            if (iframe.contentDocument && iframe.contentDocument.body) {
                // Process visible content
                processContainer(iframe.contentDocument.body, nodesToTranslate, textsToTranslate);
                
                // Process hidden containers that might be rendered later
                const hiddenContainers = iframe.contentDocument.querySelectorAll('[style*="display: none"], [style*="display:none"], .hidden, .app-data-container');
                hiddenContainers.forEach(hiddenContainer => {
                    processContainer(hiddenContainer, nodesToTranslate, textsToTranslate);
                });
            }
        } catch (e) {
            debugLog('Cannot access iframe:', e);
        }
    }
    
    return { nodesToTranslate, textsToTranslate };
}

/**
 * Apply translation to a node
 */
function applyTranslation(node, originalText, translatedText) {
    if (!node || !node.parentElement) return;
    
    node.orgn = originalText;
    node.translatedText = translatedText;
    
    if (extension_settings[extensionName]?.render) {
        node.textContent = translatedText;
    }
    
    node.parentElement.setAttribute('data-stv-translated', 'true');
    
    // Add hover event to show original
    // Use attribute to track if listener is attached (more reliable than WeakSet for dynamic DOM)
    if (!node.parentElement.hasAttribute('data-stv-hover-attached')) {
        node.parentElement.addEventListener('mouseenter', function() {
            let originalTexts = '';
            for (let i = 0; i < this.childNodes.length; i++) {
                if (this.childNodes[i].nodeType === 3 && this.childNodes[i].orgn) {
                    originalTexts += this.childNodes[i].orgn;
                }
            }
            if (originalTexts) {
                this.setAttribute('title', originalTexts);
            }
        });
        node.parentElement.setAttribute('data-stv-hover-attached', 'true');
    }
}

/**
 * Main translation function
 */
async function realtimeTranslate(forceRetranslate = false) {
    if (!extension_settings[extensionName]?.enabled) return;
    
    if (realtimeTranslateLock && !forceRetranslate) return;
    
    realtimeTranslateLock = true;
    
    // Set timeout to prevent permanent lock
    if (lockTimeoutHandle) {
        clearTimeout(lockTimeoutHandle);
    }
    lockTimeoutHandle = setTimeout(() => {
        if (realtimeTranslateLock) {
            debugLog('Lock timeout - forcing unlock');
            realtimeTranslateLock = false;
        }
    }, LOCK_TIMEOUT);
    
    try {
        // Clear markers if forced
        if (forceRetranslate) {
            const processedElements = document.querySelectorAll('[data-stv-translated]');
            processedElements.forEach(el => {
                el.removeAttribute('data-stv-translated');
            });
        }
        
        // Collect text nodes
        const { nodesToTranslate, textsToTranslate } = collectTextNodes(document);
        
        if (nodesToTranslate.length === 0) {
            debugLog('No texts to translate');
            return;
        }
        
        debugLog(`Translating ${nodesToTranslate.length} text nodes`);
        
        // Translate in batches
        const numBatches = Math.ceil(textsToTranslate.length / BATCH_SIZE);
        for (let i = 0; i < numBatches; i++) {
            const startIndex = i * BATCH_SIZE;
            const endIndex = Math.min((i + 1) * BATCH_SIZE, textsToTranslate.length);
            
            const batchTexts = textsToTranslate.slice(startIndex, endIndex);
            const batchNodes = nodesToTranslate.slice(startIndex, endIndex);
            
            const translations = await translateBatch(batchTexts);
            
            // Apply translations
            for (let j = 0; j < batchNodes.length; j++) {
                if (translations[j]) {
                    applyTranslation(batchNodes[j], batchTexts[j], translations[j]);
                }
            }
        }
        
        debugLog('Translation completed');
    } catch (error) {
        console.error('STV Translator: Error during translation', error);
    } finally {
        if (lockTimeoutHandle) {
            clearTimeout(lockTimeoutHandle);
            lockTimeoutHandle = null;
        }
        realtimeTranslateLock = false;
    }
}

/**
 * Translate single message (triggered by button click)
 */
async function translateSingleMessage(mesTextElement) {
    if (!mesTextElement) return;
    
    if (mesTextElement.hasAttribute('data-stv-translating')) {
        debugLog('Message is already being translated');
        return;
    }
    
    mesTextElement.setAttribute('data-stv-translating', 'true');
    
    try {
        // Clear markers to force re-translation
        const processedElements = mesTextElement.querySelectorAll('[data-stv-translated]');
        processedElements.forEach(el => {
            el.removeAttribute('data-stv-translated');
        });
        
        // Create a temporary document fragment to collect nodes
        const { nodesToTranslate, textsToTranslate } = collectTextNodes(mesTextElement.ownerDocument);
        
        if (nodesToTranslate.length === 0) {
            debugLog('No Chinese text found in this message');
            return;
        }
        
        const translations = await translateBatch(textsToTranslate);
        
        for (let i = 0; i < nodesToTranslate.length; i++) {
            if (translations[i]) {
                applyTranslation(nodesToTranslate[i], textsToTranslate[i], translations[i]);
            }
        }
        
        debugLog('Single message translation completed');
    } catch (error) {
        debugLog('Single message translation error:', error);
    } finally {
        mesTextElement.removeAttribute('data-stv-translating');
    }
}

/**
 * Add translate button listener
 */
function addTranslateButtonListener() {
    document.body.addEventListener('click', function(event) {
        const target = event.target;
        
        if (!(target instanceof HTMLElement)) return;
        
        if (target.classList.contains('mes_translate') ||
            target.closest('.mes_translate')) {
            
            const translateBtn = target.classList.contains('mes_translate') ?
                target : target.closest('.mes_translate');
            
            const mesBlock = translateBtn.closest('.mes_block');
            if (!mesBlock) {
                debugLog('Cannot find .mes_block parent');
                return;
            }
            
            const mesText = mesBlock.querySelector('.mes_text');
            if (!mesText) {
                debugLog('Cannot find .mes_text in this message');
                return;
            }
            
            debugLog('Translate button clicked for a single message');
            translateSingleMessage(mesText);
            
            // Visual feedback
            translateBtn.style.color = '#22d3ee';
            translateBtn.style.textShadow = '0 0 5px #22d3ee';
            setTimeout(() => {
                translateBtn.style.color = '';
                translateBtn.style.textShadow = '';
            }, 500);
            
            event.stopPropagation();
            event.preventDefault();
        }
    }, true);
}

/**
 * Toggle translation display
 */
function toggleTranslationDisplay() {
    const render = extension_settings[extensionName]?.render;
    
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
        if (node.orgn && node.translatedText) {
            if (render) {
                node.textContent = node.translatedText;
            } else {
                node.textContent = node.orgn;
            }
        }
    }
}

/**
 * Restore original text for all translated nodes
 */
function restoreOriginalText(doc = document) {
    if (!doc || !doc.body) return;
    
    // Traverse and restore text nodes
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
        if (node.orgn && node.translatedText) {
            node.textContent = node.orgn; // Restore original text
        }
    }
    
    // Clear markers to allow re-translation
    const processedElements = doc.querySelectorAll('[data-stv-translated], [data-stv-placeholder-translated]');
    processedElements.forEach(el => {
        el.removeAttribute('data-stv-translated');
        el.removeAttribute('data-stv-placeholder-translated');
    });
    
    // Restore text in iframes
    const iframes = doc.getElementsByTagName('iframe');
    for (const iframe of iframes) {
        try {
            if (iframe.contentDocument) {
                restoreOriginalText(iframe.contentDocument);
            }
        } catch (e) {
            // Cross-origin iframe, cannot access
            debugLog('Cannot access iframe:', e);
        }
    }
}

/**
 * Clear translation cache
 */
function clearCache() {
    translationCache.clear();
    namedatacache = null;
    inputDictionaryCache = null;
    debugLog('Cache cleared');
    if (typeof toastr !== 'undefined' && toastr.success) {
        toastr.success('Cache đã được xóa');
    }
}

/**
 * Add name to namedata (simplified - no dictionaries)
 */
async function addNameToData(chineseName, vietnameseName) {
    const nameEntry = `${chineseName}=${vietnameseName}`;
    const settings = extension_settings[extensionName];
    
    const currentNamedata = settings.namedata || '';
    
    // Check if name already exists
    const lines = currentNamedata.split('\n');
    let found = false;
    
    for (let i = 0; i < lines.length; i++) {
        const parts = lines[i].split('=');
        if (parts[0].trim() === chineseName) {
            lines[i] = nameEntry;
            found = true;
            break;
        }
    }
    
    if (found) {
        settings.namedata = lines.join('\n');
    } else {
        settings.namedata = currentNamedata ?
            currentNamedata + '\n' + nameEntry : nameEntry;
    }
    
    // OPTIMIZATION: Clear caches
    namedatacache = null;
    clearCache();
    saveSettingsDebounced();
    
    debugLog('Name added to namedata:', nameEntry);
    
    // Show success with cache cleared info
    if (typeof toastr !== 'undefined' && toastr.success) {
        toastr.success(
            `✓ Đã thêm: ${chineseName} = ${vietnameseName}\n✓ Cache đã được xóa`,
            'Hoàn tất',
            { timeOut: 2000 }
        );
    }
    
    // AUTO SYNC TO VP SERVER if it's a VP server
    const vpServer = extension_settings[extensionName]?.stvServer || '';
    const isVpServer = vpServer.includes('localhost') ||
                      vpServer.includes('127.0.0.1') ||
                      vpServer.includes(':500') ||
                      vpServer.includes('hf.space') ||
                      vpServer.match(/:\d{4,5}$/) ||
                      vpServer.includes('/translate');
    
    if (isVpServer && vpServer) {
        debugLog('Auto-syncing names to VP server after adding...');
        // Call sync function in background (don't await to not block UI)
        syncNamesToVpServer().then(() => {
            debugLog('Auto-sync to VP server completed');
        }).catch(err => {
            debugLog('Auto-sync to VP server failed:', err);
        });
    } else {
        // Force re-translation after short delay if not VP server
        if (extension_settings[extensionName].enabled) {
            setTimeout(() => realtimeTranslate(true), 300);
        }
    }
}


/**
 * Sync names to VP server (upload namedata from UI to Names.txt)
 */
async function syncNamesToVpServer() {
    try {
        const vpServer = extension_settings[extensionName]?.stvServer || '';
        
        if (!vpServer) {
            if (typeof toastr !== 'undefined' && toastr.warning) {
                toastr.warning('Vui lòng cấu hình VP Server URL trước');
            }
            return;
        }
        
        // Check if it's a VP server
        const isVpServer = vpServer.includes('localhost') ||
                          vpServer.includes('127.0.0.1') ||
                          vpServer.includes(':500') ||
                          vpServer.includes('hf.space') ||
                          vpServer.match(/:\d{4,5}$/) ||
                          vpServer.includes('/translate');
        
        if (!isVpServer) {
            if (typeof toastr !== 'undefined' && toastr.info) {
                toastr.info('Chức năng này chỉ hỗ trợ với VP Server');
            }
            return;
        }
        
        // Get namedata
        const namedata = extension_settings[extensionName]?.namedata || '';
        
        if (!namedata || namedata.trim() === '') {
            if (typeof toastr !== 'undefined' && toastr.warning) {
                toastr.warning('Không có dữ liệu tên để đồng bộ');
            }
            return;
        }
        
        // Count lines for progress feedback
        const lineCount = namedata.split('\n').filter(line => line.trim() && line.includes('=')).length;
        
        // Show loading toast with count
        let toastId;
        if (typeof toastr !== 'undefined' && toastr.info) {
            toastId = toastr.info(`Đang đồng bộ ${lineCount} tên LÊN VP Server...`, 'Vui lòng đợi', { timeOut: 0 });
        }
        
        // Build API URL
        let apiUrl = vpServer;
        
        // Add protocol if missing
        if (!apiUrl.startsWith('http://') && !apiUrl.startsWith('https://')) {
            const protocol = apiUrl.includes('hf.space') ? 'https://' : 'http://';
            apiUrl = protocol + apiUrl;
        }
        
        // Remove trailing slash
        apiUrl = apiUrl.replace(/\/$/, '');
        
        // Remove /translate or /translate2 if present and add /names2
        apiUrl = apiUrl.replace(/\/translate2?$/, '');
        apiUrl = `${apiUrl}/names2`;
        
        debugLog('Syncing names to:', apiUrl);
        debugLog('Namedata lines:', lineCount);
        
        // Create AbortController for timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
        
        try {
            // Send names to VP server with timeout
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ names: namedata }),
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            // Clear loading toast
            if (typeof toastr !== 'undefined' && toastr.clear && toastId) {
                toastr.clear(toastId);
            }
            
            if (!response.ok) {
                throw new Error(`Failed to sync names: ${response.status} ${response.statusText}`);
            }
            
            const data = await response.json();
            
            if (data.status === 'success') {
                debugLog('Names synced to server successfully:', data.count, 'entries');
                
                // AUTO: Clear local cache after successful sync
                clearCache();
                debugLog('Local cache auto-cleared after sync');
                
                // Show success message with cache cleared info
                if (typeof toastr !== 'undefined' && toastr.success) {
                    toastr.success(
                        `✓ Đã đồng bộ ${data.count} tên LÊN VP Server\n✓ Cache đã được xóa tự động`,
                        'Hoàn tất',
                        { timeOut: 3000 }
                    );
                }
                
                // Force re-translation with new names
                if (extension_settings[extensionName].enabled) {
                    debugLog('Auto re-translating with new names...');
                    setTimeout(() => realtimeTranslate(true), 500);
                }
            } else {
                throw new Error(data.error || 'Invalid response from VP server');
            }
        } catch (fetchError) {
            clearTimeout(timeoutId);
            
            // Clear loading toast
            if (typeof toastr !== 'undefined' && toastr.clear && toastId) {
                toastr.clear(toastId);
            }
            
            if (fetchError.name === 'AbortError') {
                throw new Error('Request timeout (>30s). Kiểm tra kết nối VP Server.');
            }
            throw fetchError;
        }
    } catch (error) {
        console.error('Sync names error:', error);
        if (typeof toastr !== 'undefined' && toastr.error) {
            toastr.error(`Lỗi đồng bộ: ${error.message}`, 'Sync Failed', { timeOut: 5000 });
        }
    }
}

/**
 * Show manual add name dialog (similar to stv.js)
 */
function showManualAddNameDialog() {
    const dialogId = 'stv-translator-manual-add-dialog';
    
    // Remove existing dialog if present
    const existingDialog = document.getElementById(dialogId);
    if (existingDialog) {
        existingDialog.remove();
    }
    
    // Remove existing style if present
    const existingStyle = document.getElementById(dialogId + '-style');
    if (existingStyle) {
        existingStyle.remove();
    }
    
    // Create and inject CSS with media query for mobile
    const styleTag = document.createElement('style');
    styleTag.id = dialogId + '-style';
    styleTag.textContent = `
        #${dialogId} {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 10000;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        #${dialogId} .dialog-content {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 450px;
            max-width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            color: black;
        }
        
        #${dialogId} .name-pair-container {
            border: 1px solid #ddd;
            padding: 10px;
            margin-bottom: 10px;
            background: #f9f9f9;
            border-radius: 4px;
        }
        
        #${dialogId} .name-pair-row {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
        }
        
        #${dialogId} .name-pair-row input {
            flex: 1;
            padding: 6px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        
        #${dialogId} .name-pair-row label {
            width: 90px;
            color: #333;
            font-size: 13px;
        }
        
        #${dialogId} .dialog-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 15px;
        }
        
        /* Media query cho điện thoại */
        @media (max-width: 600px) {
            #${dialogId} {
                align-items: flex-start;
                padding-top: 10px;
            }
            
            #${dialogId} .dialog-content {
                width: 90%;
                max-height: 90vh;
                margin-top: 10px;
                padding: 15px;
            }
            
            #${dialogId} .dialog-buttons {
                flex-direction: column;
                align-items: stretch;
            }
            
            #${dialogId} .dialog-buttons button {
                width: 100%;
            }
        }
    `;
    document.head.appendChild(styleTag);
    
    // Create dialog element
    const dialog = document.createElement('div');
    dialog.id = dialogId;
    
    dialog.innerHTML = `
        <div class="dialog-content">
            <h4 style="margin-top: 0; color: #333;">Thêm Tên (Thủ công)</h4>
            <button id="add-name-pair-btn" style="width: 100%; padding: 10px; background: #27ae60; color: white; border: none; cursor: pointer; border-radius: 4px; margin-bottom: 15px; font-weight: bold;">+ Thêm mục mới</button>
            <div id="name-pairs-container"></div>
            <div class="dialog-buttons">
                <button id="stv-manual-save-name" style="padding: 10px 20px; background: #3498db; color: white; border: none; cursor: pointer; border-radius: 4px;">Lưu & Dịch lại</button>
                <button id="stv-manual-close" style="padding: 10px 20px; background: #95a5a6; color: white; border: none; cursor: pointer; border-radius: 4px;">Đóng</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(dialog);
    
    const container = document.getElementById('name-pairs-container');
    let pairCount = 0;
    
    function addNamePair(chineseVal = '', translationVal = '') {
        pairCount++;
        const pairDiv = document.createElement('div');
        pairDiv.className = 'name-pair-container';
        pairDiv.dataset.pairId = pairCount;
        
        pairDiv.innerHTML = `
            <div class="name-pair-row">
                <label>Tiếng Trung:</label>
                <input type="text" class="chinese-input" placeholder="例: 迈克" value="${chineseVal}">
            </div>
            <div class="name-pair-row">
                <label>Bản dịch:</label>
                <input type="text" class="translation-input" placeholder="例: Mike" value="${translationVal}">
                <button class="remove-pair-btn" style="background: #e74c3c; color: white; border: none; padding: 6px 12px; cursor: pointer; border-radius: 3px;">✕</button>
            </div>
        `;
        
        container.appendChild(pairDiv);
        
        pairDiv.querySelector('.remove-pair-btn').onclick = () => {
            pairDiv.remove();
        };
        
        if (!chineseVal) {
            pairDiv.querySelector('.chinese-input').focus();
        }
    }
    
    // Add first pair
    addNamePair();
    
    document.getElementById('add-name-pair-btn').onclick = () => {
        addNamePair();
    };
    
    document.getElementById('stv-manual-save-name').onclick = async () => {
        const pairs = container.querySelectorAll('[data-pair-id]');
        const namesToAdd = [];
        
        for (const pair of pairs) {
            const chinese = pair.querySelector('.chinese-input').value.trim();
            const translation = pair.querySelector('.translation-input').value.trim();
            
            if (chinese && translation) {
                namesToAdd.push({ chinese, translation });
            } else if (chinese || translation) {
                if (typeof toastr !== 'undefined' && toastr.error) {
                    toastr.error('Vui lòng điền đầy đủ cả Tiếng Trung và Bản dịch cho tất cả các mục, hoặc xóa mục trống.');
                }
                return;
            }
        }
        
        if (namesToAdd.length === 0) {
            if (typeof toastr !== 'undefined' && toastr.error) {
                toastr.error('Vui lòng thêm ít nhất một cặp tên.');
            }
            return;
        }
        
        // Show loading toast
        let toastId;
        if (typeof toastr !== 'undefined' && toastr.info) {
            toastId = toastr.info(`Đang thêm ${namesToAdd.length} tên...`, 'Vui lòng đợi', { timeOut: 0 });
        }
        
        try {
            // OPTIMIZATION: Batch add all names at once without individual toasts
            for (const name of namesToAdd) {
                const nameEntry = `${name.chinese}=${name.translation}`;
                const currentNamedata = extension_settings[extensionName]?.namedata || '';
                const lines = currentNamedata.split('\n');
                let found = false;
                
                for (let i = 0; i < lines.length; i++) {
                    const parts = lines[i].split('=');
                    if (parts[0].trim() === name.chinese) {
                        lines[i] = nameEntry;
                        found = true;
                        break;
                    }
                }
                
                if (found) {
                    extension_settings[extensionName].namedata = lines.join('\n');
                } else {
                    extension_settings[extensionName].namedata = extension_settings[extensionName].namedata ?
                        extension_settings[extensionName].namedata + '\n' + nameEntry : nameEntry;
                }
            }
            
            // Clear caches once after all additions
            namedatacache = null;
            clearCache();
            saveSettingsDebounced();
            
            // Update namedata textarea in settings if open
            $('#stv_namedata').val(extension_settings[extensionName].namedata);
            
            // Clear loading toast
            if (typeof toastr !== 'undefined' && toastr.clear && toastId) {
                toastr.clear(toastId);
            }
            
            dialog.remove();
            
            // Show success message
            if (typeof toastr !== 'undefined' && toastr.success) {
                toastr.success(
                    `✓ Đã thêm ${namesToAdd.length} tên\n✓ Cache đã được xóa`,
                    'Hoàn tất',
                    { timeOut: 2000 }
                );
            }
            
            // AUTO SYNC TO VP SERVER if it's a VP server
            const vpServer = extension_settings[extensionName]?.stvServer || '';
            const isVpServer = vpServer.includes('localhost') ||
                              vpServer.includes('127.0.0.1') ||
                              vpServer.includes(':500') ||
                              vpServer.includes('hf.space') ||
                              vpServer.match(/:\d{4,5}$/) ||
                              vpServer.includes('/translate');
            
            if (isVpServer && vpServer) {
                debugLog('Auto-syncing names to VP server after adding...');
                // Call sync function in background (don't await to not block UI)
                syncNamesToVpServer().then(() => {
                    debugLog('Auto-sync to VP server completed');
                }).catch(err => {
                    debugLog('Auto-sync to VP server failed:', err);
                });
            } else {
                // Force re-translation after short delay if not VP server
                if (extension_settings[extensionName].enabled) {
                    setTimeout(() => realtimeTranslate(true), 300);
                }
            }
        } catch (error) {
            // Clear loading toast on error
            if (typeof toastr !== 'undefined' && toastr.clear && toastId) {
                toastr.clear(toastId);
            }
            
            if (typeof toastr !== 'undefined' && toastr.error) {
                toastr.error(`Lỗi: ${error.message}`, 'Thêm tên thất bại');
            }
        }
    };
    
    // Cleanup function to remove dialog and style
    const cleanup = () => {
        dialog.remove();
        styleTag.remove();
    };
    
    document.getElementById('stv-manual-close').onclick = cleanup;
    
    // Close on backdrop click
    dialog.onclick = (e) => {
        if (e.target === dialog) {
            cleanup();
        }
    };
}

/**
 * Load settings
 */
function loadSettings() {
    if (!extension_settings[extensionName]) {
        extension_settings[extensionName] = {};
    }
    
    for (const key in defaultSettings) {
        if (!Object.hasOwn(extension_settings[extensionName], key)) {
            extension_settings[extensionName][key] = defaultSettings[key];
        }
    }
    
    // Update UI
    $('#stv_enabled').prop('checked', extension_settings[extensionName].enabled);
    $('#stv_render').prop('checked', extension_settings[extensionName].render);
    $('#stv_debug').prop('checked', extension_settings[extensionName].debug);
    $('#stv_cache_enabled').prop('checked', extension_settings[extensionName].cacheEnabled);
    $('#stv_translate_only_reasoning').prop('checked', extension_settings[extensionName].translateOnlyReasoning);
    $('#stv_server').val(String(extension_settings[extensionName].stvServer));
    $('#stv_max_retries').val(String(extension_settings[extensionName].maxRetries));
    $('#stv_namedata').val(String(extension_settings[extensionName].namedata));
    $('#stv_input_dictionary').val(String(extension_settings[extensionName].inputDictionary || ''));
    $('#stv_excludes').val(String(extension_settings[extensionName].excludes));
    
    // Load Gemini settings
    $('#stv_gemini_api_key').val(String(extension_settings[extensionName].geminiApiKey || ''));
    $('#stv_gemini_model').val(String(extension_settings[extensionName].geminiModel || 'gemini-2.0-flash-exp'));
    $('#stv_gemini_proxy_endpoint').val(String(extension_settings[extensionName].geminiProxyEndpoint || ''));
    $('#stv_enable_input_translation').prop('checked', extension_settings[extensionName].enableInputTranslation);
    
    debugLog('Settings loaded');
}


/**
 * Save settings
 */
function saveSettings() {
    extension_settings[extensionName].enabled = Boolean($('#stv_enabled').prop('checked'));
    extension_settings[extensionName].render = Boolean($('#stv_render').prop('checked'));
    extension_settings[extensionName].debug = Boolean($('#stv_debug').prop('checked'));
    extension_settings[extensionName].cacheEnabled = Boolean($('#stv_cache_enabled').prop('checked'));
    extension_settings[extensionName].translateOnlyReasoning = Boolean($('#stv_translate_only_reasoning').prop('checked'));
    extension_settings[extensionName].stvServer = String($('#stv_server').val() || '');
    extension_settings[extensionName].maxRetries = parseInt(String($('#stv_max_retries').val())) || 2;
    extension_settings[extensionName].namedata = String($('#stv_namedata').val() || '');
    extension_settings[extensionName].inputDictionary = String($('#stv_input_dictionary').val() || '');
    extension_settings[extensionName].excludes = String($('#stv_excludes').val() || '');
    extension_settings[extensionName].geminiProxyEndpoint = String($('#stv_gemini_proxy_endpoint').val() || '');
    
    saveSettingsDebounced();
    debugLog('Settings saved');
}

/**
 * Start MutationObserver for auto-translation
 * ENHANCED: Also observes attribute changes to catch dynamic content
 */
function startObserver() {
    if (mutationObserver) {
        mutationObserver.disconnect();
    }
    
    mutationObserver = new MutationObserver(() => {
        if (mutationObserver.debounce) clearTimeout(mutationObserver.debounce);
        mutationObserver.debounce = setTimeout(() => realtimeTranslate(false), DEBOUNCE_TIME);
    });
    
    mutationObserver.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['style', 'class', 'hidden'],
    });
    
    debugLog('MutationObserver started with enhanced detection');
}

/**
 * Stop MutationObserver
 */
function stopObserver() {
    if (mutationObserver) {
        mutationObserver.disconnect();
        mutationObserver = null;
    }
    debugLog('MutationObserver stopped');
}

/**
 * Start periodic scanner for dynamic content
 * Scans every 3 seconds to catch content rendered by JavaScript
 */
function startPeriodicScanner() {
    if (periodicScanner) {
        clearInterval(periodicScanner);
    }
    
    periodicScanner = setInterval(() => {
        if (!realtimeTranslateLock && extension_settings[extensionName]?.enabled) {
            debugLog('Periodic scan triggered');
            realtimeTranslate(false);
        }
    }, 3000); // Scan every 3 seconds
    
    debugLog('Periodic scanner started (every 3s)');
}

/**
 * Stop periodic scanner
 */
function stopPeriodicScanner() {
    if (periodicScanner) {
        clearInterval(periodicScanner);
        periodicScanner = null;
    }
    debugLog('Periodic scanner stopped');
}

/**
 * Initialize extension
 */
jQuery(async () => {
    // Load HTML templates for EXTERNAL extension
    // External extensions are served from /scripts/extensions/third-party/<name>/
    const extensionFolderPath = `scripts/extensions/third-party/${extensionName}`;
    
    try {
        // Load settings template
        const settingsResponse = await fetch(`/${extensionFolderPath}/settings.html`);
        if (!settingsResponse.ok) {
            throw new Error(`Failed to load settings.html: ${settingsResponse.status}`);
        }
        const settingsHtml = await settingsResponse.text();
        $('#extensions_settings').append(settingsHtml);
        
        // Load button template
        const buttonResponse = await fetch(`/${extensionFolderPath}/buttons.html`);
        if (!buttonResponse.ok) {
            throw new Error(`Failed to load buttons.html: ${buttonResponse.status}`);
        }
        const buttonHtml = await buttonResponse.text();
        $('#translate_wand_container').append(buttonHtml);
    } catch (error) {
        console.error('STV Translator: Failed to load templates', error);
        // Fallback: create minimal UI
        $('#extensions_settings').append('<div id="stv-translator-error" style="color: red;">Failed to load extension templates. Check console for details.</div>');
        return;
    }
    
    // Load settings
    loadSettings();
    
    // Event listeners
    $('#stv_enabled').on('change', function() {
        extension_settings[extensionName].enabled = $(this).prop('checked');
        saveSettingsDebounced();
        if ($(this).prop('checked')) {
            startObserver();
            startPeriodicScanner();
            realtimeTranslate(false);
        } else {
            stopObserver();
            stopPeriodicScanner();
            // Khôi phục text gốc khi tắt dịch
            restoreOriginalText();
        }
    });
    
    $('#stv_render').on('change', function() {
        extension_settings[extensionName].render = $(this).prop('checked');
        saveSettingsDebounced();
        toggleTranslationDisplay();
    });
    
    $('#stv_debug').on('change', function() {
        extension_settings[extensionName].debug = $(this).prop('checked');
        saveSettingsDebounced();
    });
    
    $('#stv_cache_enabled').on('change', function() {
        extension_settings[extensionName].cacheEnabled = $(this).prop('checked');
        saveSettingsDebounced();
    });
    
    $('#stv_translate_only_reasoning').on('change', function() {
        extension_settings[extensionName].translateOnlyReasoning = $(this).prop('checked');
        saveSettingsDebounced();
    });
    
    $('#stv_server').on('input', function() {
        extension_settings[extensionName].stvServer = String($(this).val() || '');
        saveSettingsDebounced();
    });
    
    $('#stv_max_retries').on('input', function() {
        extension_settings[extensionName].maxRetries = parseInt(String($(this).val())) || 2;
        saveSettingsDebounced();
    });
    
    $('#stv_namedata').on('input', function() {
        extension_settings[extensionName].namedata = String($(this).val() || '');
        namedatacache = null;
        saveSettingsDebounced();
    });
    
    $('#stv_input_dictionary').on('input', function() {
        extension_settings[extensionName].inputDictionary = String($(this).val() || '');
        inputDictionaryCache = null;
        saveSettingsDebounced();
    });
    
    $('#stv_excludes').on('input', function() {
        extension_settings[extensionName].excludes = String($(this).val() || '');
        saveSettingsDebounced();
    });
    
    $('#stv_clear_cache').on('click', function() {
        clearCache();
        realtimeTranslate(true);
    });
    
    $('#stv_translate_all').on('click', function() {
        realtimeTranslate(true);
    });
    
    $('#stv_add_name_form').on('submit', async function(e) {
        e.preventDefault();
        const chinese = String($('#stv_name_chinese').val() || '').trim();
        const vietnamese = String($('#stv_name_vietnamese').val() || '').trim();
        if (chinese && vietnamese) {
            await addNameToData(chinese, vietnamese);
            $('#stv_name_chinese').val('');
            $('#stv_name_vietnamese').val('');
            // Re-translation is now handled inside addNameToData (or auto-sync will trigger it)
        }
    });
    
    // Event listener cho nút sync names LÊN VP server
    $('#stv_sync_names_vp').on('click', function() {
        syncNamesToVpServer();
    });
    
    // Event handler cho nút toggle trong thanh công cụ nhanh
    $('#stv_toggle_translate').on('click', function() {
        // Toggle trạng thái enabled
        extension_settings[extensionName].enabled = !extension_settings[extensionName].enabled;
        
        // Cập nhật checkbox trong settings
        $('#stv_enabled').prop('checked', extension_settings[extensionName].enabled);
        
        // Lưu settings
        saveSettingsDebounced();
        
        // Bật/tắt observer và periodic scanner
        if (extension_settings[extensionName].enabled) {
            startObserver();
            startPeriodicScanner();
            realtimeTranslate(false);
            if (typeof toastr !== 'undefined' && toastr.success) {
                toastr.success('Đã BẬT dịch tự động STV');
            }
            // Visual feedback - đổi màu nút
            $(this).find('.fa-language').css('color', '#22d3ee');
        } else {
            stopObserver();
            stopPeriodicScanner();
            // Khôi phục text gốc khi tắt dịch
            restoreOriginalText();
            if (typeof toastr !== 'undefined' && toastr.info) {
                toastr.info('Đã TẮT dịch tự động STV');
            }
            // Visual feedback - màu xám
            $(this).find('.fa-language').css('color', '#999');
        }
    });
    
    // Cập nhật màu icon ban đầu dựa trên trạng thái
    if (extension_settings[extensionName].enabled) {
        $('#stv_toggle_translate').find('.fa-language').css('color', '#22d3ee');
    } else {
        $('#stv_toggle_translate').find('.fa-language').css('color', '#999');
    }
    
    // Event handler cho nút "Thêm Tên" trong thanh công cụ nhanh
    $('#stv_add_name').on('click', function() {
        showManualAddNameDialog();
    });
    
    // Event handler cho nút dịch input (Gemini)
    $('#stv_translate_input').on('click', function() {
        translateInputMessage();
    });
    
    // Event handlers cho Gemini settings
    $('#stv_gemini_api_key').on('input', function() {
        extension_settings[extensionName].geminiApiKey = String($(this).val() || '');
        saveSettingsDebounced();
    });
    
    $('#stv_gemini_model').on('input', function() {
        extension_settings[extensionName].geminiModel = String($(this).val() || '');
        saveSettingsDebounced();
    });
    
    $('#stv_gemini_proxy_endpoint').on('input', function() {
        extension_settings[extensionName].geminiProxyEndpoint = String($(this).val() || '');
        saveSettingsDebounced();
    });
    
    $('#stv_enable_input_translation').on('change', function() {
        extension_settings[extensionName].enableInputTranslation = $(this).prop('checked');
        saveSettingsDebounced();
    });
    
    
    // Add translate button listener
    addTranslateButtonListener();
    
    // Start observer and periodic scanner if enabled
    if (extension_settings[extensionName].enabled) {
        startObserver();
        startPeriodicScanner();
        // Initial translation after delay
        setTimeout(() => realtimeTranslate(false), 1000);
    }
    
    // Slash command
    SlashCommandParser.addCommandObject(SlashCommand.fromProps({
        name: 'stv-translate',
        helpString: 'Translate text using STV (Chinese to Vietnamese)',
        unnamedArgumentList: [
            new SlashCommandArgument('text to translate', ARGUMENT_TYPE.STRING, true),
        ],
        callback: async (args, value) => {
            const text = String(value);
            if (!text) {
                return 'Please provide text to translate';
            }
            return await translateText(text);
        },
        returns: ARGUMENT_TYPE.STRING,
    }));
    
    debugLog('STV Translator initialized');
    console.log('STV Realtime Translator extension loaded');
});