# STV Translator Extension

Extension tích hợp dịch thuật tự động từ tiếng Trung sang tiếng Việt cho SillyTavern, sử dụng API dịch SangTacViet (STV).

## Tính năng

- ✅ Dịch tự động các tin nhắn có chứa tiếng Trung trong SillyTavern
- ✅ Dịch theo thời gian thực khi có nội dung mới
- ✅ Hỗ trợ dịch chỉ Reasoning Messages hoặc tất cả tin nhắn
- ✅ Cache bản dịch để tăng tốc độ
- ✅ Thay thế tên riêng (tên nhân vật, địa danh) tùy chỉnh
- ✅ Hiển thị văn bản gốc khi hover chuột
- ✅ Retry logic khi gặp lỗi kết nối
- ✅ Loại trừ trang web không muốn dịch
- ✅ Slash command `/stv-translate` để dịch thủ công

## Cài đặt

Extension này là **external/third-party extension** cho SillyTavern.

### Cài đặt tự động (Khuyến nghị)

1. Tải file extension về
2. Copy thư mục `stv-translator/` vào:
   ```
   SillyTavern/data/default-user/extensions/third-party/
   ```
3. Khởi động lại SillyTavern
4. Extension sẽ tự động xuất hiện trong danh sách Extensions

### Cài đặt thủ công

1. Đặt toàn bộ thư mục `stv-translator/` vào đúng vị trí:
   ```
   SillyTavern/
   └── data/
       └── default-user/
           └── extensions/
               └── third-party/
                   └── stv-translator/
                       ├── manifest.json
                       ├── index.js
                       ├── settings.html
                       ├── buttons.html
                       ├── style.css
                       └── README.md
   ```

2. Restart SillyTavern server
3. Vào **Extensions** menu (icon puzzle piece)
4. Tìm **STV Translator** và bật extension

### Kiểm tra cài đặt thành công

Mở Browser Console (F12) và tìm log:
```
STV Realtime Translator extension loaded
```

Nếu thấy log này → Extension đã load thành công! ✅

## Cấu hình

### Cài đặt cơ bản

- **Enable Translation**: Bật/tắt dịch tự động
- **Render Translation**: Hiển thị bản dịch hoặc văn bản gốc
- **Translate Only Reasoning**: Chỉ dịch các tin nhắn có class `.reasoning`
- **Enable Cache**: Bật cache để tăng tốc độ dịch
- **Debug Mode**: Hiển thị logs trong console để debug

### Cài đặt nâng cao

- **Server URL**: Địa chỉ server dịch (mặc định: `comic.sangtacvietcdn.xyz/tsm.php?cdn=`)
- **Max Retries**: Số lần thử lại khi lỗi (0-5)
- **Name Data**: Danh sách tên riêng để thay thế
- **Exclude Pages**: Danh sách trang không dịch (hỗ trợ wildcard và regex)

### Thêm tên riêng

Định dạng: `TiếngTrung=TiếngViệt`

Ví dụ:
```
迈克=Mike
张三=Trương Tam
李四=Lý Tứ
```

**Lưu ý**: Tên dài hơn sẽ được ưu tiên thay thế trước để tránh conflict.

### Loại trừ trang web

Hỗ trợ 3 định dạng:

1. **Exact match**: `google.com`
2. **Wildcard**: `*.example.com`, `test*.org`
3. **Regex**: `/^test.*\.org$/`

Ví dụ:
```
google.com
*.ads.com
/^test.*\.org$/
```

## Sử dụng

### Dịch tự động

Khi extension được bật, mọi tin nhắn có tiếng Trung sẽ tự động được dịch.

### Dịch thủ công

Sử dụng slash command:
```
/stv-translate
```

### Xem văn bản gốc

Di chuột vào văn bản đã dịch để xem tooltip hiển thị văn bản gốc.

### Bật/Tắt hiển thị bản dịch

Click vào nút "Bật/Tắt Dịch" trong menu SillyTavern hoặc dùng checkbox "Render Translation" trong settings.

## Troubleshooting

### Extension không hoạt động

1. Kiểm tra Extension đã được bật chưa
2. Mở Console (F12) và bật Debug Mode để xem logs
3. Kiểm tra kết nối internet
4. Thử xóa cache và reload trang

### Dịch sai hoặc không dịch

1. Kiểm tra server URL có đúng không
2. Tăng số Max Retries
3. Xóa cache và dịch lại
4. Kiểm tra văn bản có chứa ký tự Trung Quốc không

### Tên riêng không được thay thế

1. Kiểm tra định dạng Name Data (phải là `TiếngTrung=TiếngViệt`)
2. Tên dài hơn được ưu tiên, nên đảm bảo thêm cả tên đầy đủ
3. Xóa cache sau khi thêm tên mới

## Giới hạn

- Chỉ dịch được tiếng Trung sang tiếng Việt
- Phụ thuộc vào server API bên ngoài (STV)
- Cache tối đa 1000 mục

## Credits

- Based on original Tampermonkey script by BQY
- Integrated into SillyTavern by AI Assistant
- Translation API: SangTacViet (comic.sangtacvietcdn.xyz)

## License

Tương tự license của SillyTavern (AGPL-3.0)