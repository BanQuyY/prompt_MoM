/**
 * ESLint Configuration for STV Translator Extension
 *
 * Các rules bị tắt vì lý do kỹ thuật:
 *
 * 1. @typescript-eslint/ban-ts-comment:
 *    - Extension sử dụng custom properties trên Node objects (node.orgn, node.translatedText)
 *    - Cần @ts-ignore để tránh TypeScript warnings về properties không tồn tại
 *    - Đây là false positives vì JavaScript cho phép thêm properties động
 *
 * 2. @typescript-eslint/no-explicit-any:
 *    - Một số global variables của SillyTavern (toastr, jQuery) không có type definitions
 *    - Extension cần tương tác với DOM và APIs không được type đầy đủ
 *    - Sử dụng 'any' trong trường hợp này là an toàn và cần thiết
 *
 * Lưu ý: Các warnings này KHÔNG ảnh hưởng đến runtime functionality.
 * Extension hoạt động hoàn toàn bình thường trong production.
 */
module.exports = {
    rules: {
        '@typescript-eslint/ban-ts-comment': 'off',
        '@typescript-eslint/no-explicit-any': 'off',
    },
};